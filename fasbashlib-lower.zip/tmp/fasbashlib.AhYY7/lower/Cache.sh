#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_VERSION="v0.2.3.r306.g563d186-lower"
FSBLIB_REQUIRE="ModernBash"

Cache.exist () 
{ 
    local _File;
    _File="$(Cache.createDir)/$1";
    [[ -e "$_File" ]] || return 1;
    (( "$(Cache.getTimeDiffFromLastUpdate "$_File")" > "${KEEPCACHESEC-"86400"}" )) && return 2;
    return 0
}
Cache.get () 
{ 
    cat "$(Cache.getDir)/$1" 2> /dev/null || return 1
}
Cache.getDir () 
{ 
    echo "${TMPDIR-"/tmp"}/$(Cache.getID)"
}
Cache.getFileLastUpdate () 
{ 
    local _isGnu=false;
    date --help 2> /dev/null | grep -q "GNU" && _isGnu=true;
    if [[ "$_isGnu" = true ]]; then
        date +%s -r "$1";
    else
        { 
            eval "$(stat -s "$1")";
            echo "$st_mtime"
        };
    fi
}
Cache.getID () 
{ 
    if [[ -z "${FSBLIB_CACHEID-""}" ]]; then
        Cache.createDir > /dev/null;
    fi;
    echo "$FSBLIB_CACHEID"
}
Cache.getTimeDiffFromLastUpdate () 
{ 
    local _Now _Last;
    _Now="$(date "+%s")";
    _Last="$(Cache.getFileLastUpdate "$1")";
    echo "$(( _Now - _Last ))";
    return 0
}
Cache.create () 
{ 
    Cache.createDir > /dev/null;
    cat > "$(Cache.getDir)/${1}";
    cat "$(Cache.getDir)/$1"
}
Cache.createDir () 
{ 
    FSBLIB_CACHEID="${FSBLIB_CACHEID-"$(RandomString "10")"}";
    export FSBLIB_CACHEID="$FSBLIB_CACHEID";
    local TMPDIR="${TMPDIR-"/tmp"}";
    local _Dir="$TMPDIR/${FSBLIB_CACHEID}";
    mkdir -p "$_Dir";
    echo "$_Dir";
    return 0
}
