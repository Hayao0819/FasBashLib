#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_VERSION="0.2.4.r234.g5c62fb4-lower"
FSBLIB_REQUIRE="ModernBash"

addNewToArray () 
{ 
    Array.Push "$@"
}
arrayAppend () 
{ 
    Array.Append "$1"
}
arrayIncludes () 
{ 
    Array.Includes "$@"
}
arrayIndex () 
{ 
    Array.Length "$1"
}
getarrayIndex () 
{ 
    Array.IndexOf "$1"
}
printArray () 
{ 
    Array.Print "$@"
}
printEvalArray () 
{ 
    Array.Eval "$1"
}
revArray () 
{ 
    Array.Rev "$1"
}
strToCharList () 
{ 
    Array.FromStr "$1"
}
fileType () 
{ 
    file --mime-type -b "$1"
}
getBaseName () 
{ 
    forEach basename "{}"
}
getFileExt () 
{ 
    getBaseName | rev | cut -d "." -f 1 | rev
}
removeFileExt () 
{ 
    local Ext;
    forEach eval 'Ext=$(getFileExt <<< {}); sed "s|.$Ext$||g" <<< {}; unset Ext'
}
checkFuncDefined () 
{ 
    typeset -f "${1}" > /dev/null || return 1
}
forEach () 
{ 
    local _Item;
    while read -r _Item; do
        "${@//"{}"/"${_Item}"}" || return "${?}";
    done
}
getLine () 
{ 
    head -n "$1" | tail -n 1
}
isAvailable () 
{ 
    type "$1" 2> /dev/null 1>&2
}
loop () 
{ 
    local _T="$1";
    shift 1 || return 1;
    forEach "$@" < <(yes "" | head -n "$_T")
}
breakChar () 
{ 
    grep -o "."
}
cutLastString () 
{ 
    echo "${1%%"${2}"}";
    return 0
}
getLastSplitString () 
{ 
    rev <<< "$2" | cut -d "$1" -f 1 | rev
}
isUUID () 
{ 
    local _UUID="${1-""}";
    [[ "${_UUID//-/}" =~ ^[[:xdigit:]]{32}$ ]] && return 0;
    return 1
}
printEval () 
{ 
    eval echo "\${$1}"
}
randomString () 
{ 
    base64 < "/dev/random" | fold -w "$1" | head -n 1;
    return 0
}
removeBlank () 
{ 
    sed "s|^ *||g; s| *$||g; s|^	*||g; s|	*$||g; /^$/d"
}
textBox () 
{ 
    local _Content=() _Length _Vertical="|" _Line="=";
    readarray -t _Content;
    _Length="$(printArray "${_Content[@]}" | awk '{ if ( length > x ) { x = length } }END{ print x }')";
    echo "${_Vertical}${_Line}$(yes "${_Line}" | head -n "$_Length" | tr -d "\n")${_Vertical}";
    for _Str in "${_Content[@]}";
    do
        echo "${_Vertical}${_Str}$(yes " " | head -n "$(( _Length + 1 - "${#_Str}"))" | tr -d "\n")${_Vertical}";
    done;
    echo "${_Vertical}${_Line}$(yes "${_Line}" | head -n "$_Length" | tr -d "\n")${_Vertical}"
}
toLower () 
{ 
    local _Str="${1,,}";
    [[ -z "${_Str-""}" ]] || echo "${_Str}"
}
toLowerStdin () 
{ 
    local _Str;
    forEach eval "_Str=\"{}\"; echo \"\${_Str,,}\"";
    unset _Str
}
calcInt () 
{ 
    echo "$(( "$@" ))"
}
ntest () 
{ 
    (( "$@" )) || return 1
}
sum () 
{ 
    local _Arg=();
    forEach eval '_Arg+=("{}" "+")' < <(printArray "$@");
    readarray -t _Arg < <(printArray "${_Arg[@]}" | sed "${#_Arg[@]}d");
    calcInt "${_Arg[@]}"
}
bool () 
{ 
    case "$(toLower "$(printEval "${1}")")" in 
        "true")
            return 0
        ;;
        "" | "false")
            return 1
        ;;
        *)
            return 2
        ;;
    esac
}
getFuncList () 
{ 
    declare -F | cut -d " " -f 3
}
unsetAllFunc () 
{ 
    local Func;
    while read -r Func; do
        unset "$Func";
    done < <(getFuncList)
}
removeMatchLine () 
{ 
    local i unseted=false;
    while read -r i; do
        if [[ "$i" != "${1}" ]] || [[ "${unseted}" = true ]]; then
            echo "$i";
        else
            unseted=true;
        fi;
    done;
    unset unseted i
}
