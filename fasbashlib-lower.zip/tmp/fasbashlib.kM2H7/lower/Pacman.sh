#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all
declare -r FSBLIB_LIBLIST=("Pacman" )
declare -r FSBLIB_VERSION='v0.2.3.r405.g8733e6d-lower'
declare -r FSBLIB_REQUIRE='ModernBash'
Pm.checkPkg () 
{ 
    local p;
    for p in "$@";
    do
        Pm.run -Qq "$p" > /dev/null 2>&1 || return 1;
    done;
    return 0
}
Pm.getConfig () 
{ 
    LANG=C pacman-conf --config="${PACMAN_CONF-"/etc/pacman.conf"}" "$@"
}
Pm.getInstalledPkgVer () 
{ 
    ForEach pacman -Qq "{}" | cut -d " " -f 2;
    PrintArray "${PIPESTATUS[@]}" | grep -qx "1" && return 1;
    return 0
}
Pm.getKeyringList () 
{ 
    find "$(@GetKeyringDir)" -name "*.gpg" | GetBaseName | RemoveFileExt
}
Pm.getLatestPkgVer () 
{ 
    local _LANG="${LANG-""}";
    export LANG=C;
    ForEach Pm.run -Si "{}" | grep "^Version" | cut -d ":" -f 2 | RemoveBlank;
    [[ -n "$_LANG" ]] && export LANG="$_LANG";
    return 0
}
Pm.getName () 
{ 
    cut -d "<" -f 1 | cut -d ">" -f 1 | cut -d "=" -f 1
}
Pm.getPacmanKernelPkg () 
{ 
    echo "there is nothing"
}
Pm.getPacmanKeyringDir () 
{ 
    local _KeyringDir="";
    _KeyringDir="$(LANG=C pacman-key -h | RemoveBlank | grep -A 1 -- "^--populate" | tail -n 1 | cut -d "/" -f 2- | sed "s|'$||g")";
    : "${_KeyringDir="usr/share/pacman/keyrings"}";
    _KeyringDir="$(Pm.getRoot)/$_KeyringDir";
    _KeyringDir="$(sed -E "s|/+|/|g" <<< "$_KeyringDir")";
    if [[ -e "$_KeyringDir" ]]; then
        Readlinkf "$_KeyringDir";
    else
        echo "$_KeyringDir";
    fi
}
Pm.getRepoConf () 
{ 
    ForEach eval 'echo [{}] && Pm.getConfig -r {}'
}
Pm.getRepoListFromConf () 
{ 
    Pm.getConfig --repo-list
}
Pm.getRepoPkgList () 
{ 
    Pm.run -Slq "$@"
}
Pm.getRepoServer () 
{ 
    ForEach eval 'Pm.getConfig -r {}' | grep "^Server" | ForEach eval "Ini.ParseLine <<< '{}' ; printf '%s\n' \${VALUE}"
}
Pm.getRepoVer () 
{ 
    Pm.run -Sp --print-format '%v' "$1"
}
Pm.getRoot () 
{ 
    Pm.getConfig RootDir
}
Pm.isRepoPkg () 
{ 
    Pm.run -Slq | grep -qx "$(Pm.getName <<< "$1")"
}
Pm.pacmanGpg () 
{ 
    gpg --homedir "$(Pm.getConfig GPGDir)" "$@"
}
Pm.run () 
{ 
    pacman --noconfirm --config "${PACMAN_CONF-"/etc/pacman.conf"}" "$@"
}
Pm.runKey () 
{ 
    pacman-key --config "${PACMAN_CONF-"/etc/pacman.conf"}" "$@"
}
Pm.getDbNextSection () 
{ 
    Pm.getDbSectionList | grep -x -A 1 "^%$1%$" | GetLine 2 | sed "s|^%||g; s|%$||g"
}
Pm.getDbSection () 
{ 
    readarray -t _Stdin;
    PrintArray "${_Stdin[@]}" | sed -ne "/^%$1%$/,/^%$(PrintEvalArray _Stdin | Pm.getDbNextSection "$1")%$/p" | sed "1d; \$d"
}
Pm.getDbSectionList () 
{ 
    grep -E "^%.*%$"
}
Pm.createDbTmpDir () 
{ 
    mkdir -p "$(Pm.getDbTmpDir)"
}
Pm.deleteDbTmpDir () 
{ 
    rm -rf "$(Pm.getDbTmpDir)"
}
Pm.getDbTmpDir () 
{ 
    echo "${TMPDIR-"/tmp"}/fasbashlib-pacman-db"
}
Pm.getPkgArch () 
{ 
    Pm.getSyncDbDesc "$1" | Pm.getDbSection ARCH | RemoveBlank
}
Pm.getRepoListFromLocalDb () 
{ 
    find "$(Pm.getConfig DBPath)/sync" -mindepth 1 -maxdepth 1 -type f | GetBaseName | sed "s|.db$||g";
    return 0
}
Pm.getSyncAllDesc () 
{ 
    find "$(Pm.getDbTmpDir)" -mindepth 3 -maxdepth 3 -name "desc" -type f
}
Pm.getSyncDbDesc () 
{ 
    local _path;
    _path="$(Pm.getSyncDbDescPath "$1")";
    [[ -e "$_path" ]] || return 1;
    cat "$_path/desc"
}
Pm.getSyncDbDescPath () 
{ 
    local _repo;
    _repo="$(pacman -Sp --print-format '%r' "$1")";
    { 
        IsPacmanSyncDbOpend "$_repo" || OpenPacmanSyncDb "$_repo"
    } || return 1;
    echo "$(Pm.getDbTmpDir)/sync/$(pacman -Sp --print-format '%r/%n-%v' "$1")"
}
Pm.getVirtualPkgList () 
{ 
    Pm.getRepoListFromLocalDb | ForEach Pm.openSyncDb {};
    Pm.getSyncAllDesc | ForEach eval "Pm.getDbSection PROVIDES < {}" | RemoveBlank
}
Pm.isOpendSyncDb () 
{ 
    readarray -t _PkgDbList < <(find "$(Pm.getDbTmpDir)/sync/$1" -mindepth 1 -maxdepth 1 -type d );
    (( "${#_PkgDbList[@]}" > 0 )) && return 0;
    return 1
}
Pm.openSyncDb () 
{ 
    local _Dir _RepoDb;
    Pm.createDbTmpDir;
    _Dir="$(Pm.getDbTmpDir)/sync/$1";
    mkdir -p "$_Dir";
    _RepoDb="$(Pm.getConfig DBPath)/sync/$1.db";
    [[ -e "$_RepoDb" ]] || return 1;
    tar -xzf "${_RepoDb}" -C "$_Dir" || return 1
}
Pm.openedSyncDbList () 
{ 
    find "$(Pm.getDbTmpDir)/sync/" -mindepth 1 -maxdepth 1 -type d
}
Pm.parsePkgFileName () 
{ 
    local _Pkg="$1";
    local _PkgName _PkgVer _PkgRel _Arch _FileExt;
    local _PkgWithOutExt;
    if grep "/" <<< "$_Pkg"; then
        _Pkg="$(basename "$_Pkg")";
    fi;
    _FileExt="$(GetLastSplitString "-" "$_Pkg" | cut -d "." -f 2-)";
    _PkgWithOutExt="${_Pkg%%".${_FileExt}"}";
    _Arch=$(GetLastSplitString "-" "${_PkgWithOutExt}");
    _PkgRel=$(GetLastSplitString "-" "${_PkgWithOutExt%%"-${_Arch}"}");
    _PkgVer=$(GetLastSplitString "-" "${_PkgWithOutExt%%"-${_PkgRel}-${_Arch}"}");
    _PkgName="${_PkgWithOutExt%%"-${_PkgVer}-${_PkgRel}-${_Arch}"}";
    _ParsedPkg=("${_PkgName}" "-" "$_PkgVer" "-" "$_PkgRel" "-" "$_Arch" ".$_FileExt");
    if [[ ! "$(PrintArray "${_ParsedPkg[@]}" | tr -d "\n")" = "${_Pkg}" ]]; then
        return 1;
    fi;
    PrintArray "${_ParsedPkg[@]}"
}
