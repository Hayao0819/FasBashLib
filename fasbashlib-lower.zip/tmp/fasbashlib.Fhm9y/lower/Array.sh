#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

declare -r FSBLIB_VERSION="v0.2.3.r380.gbbcc054-lower"
declare -r FSBLIB_REQUIRE="ModernBash"


Array.append () 
{ 
    local _ArrName="$1";
    shift 1 || return 1;
    readarray -t -O "$(ArrayIndex "$_ArrName")" "$_ArrName" < <(cat)
}
Array.fromStr () 
{ 
    declare -a -x "$1";
    readarray -t "$1" < <(BreakChar)
}
Array.pop () 
{ 
    readarray -t "$1" < <(PrintEvalArray "$1" | sed -e '$d')
}
Array.push () 
{ 
    eval "PrintArray \"\${$1[@]}\"" | grep -qx "$2" && return 0;
    eval "$1+=(\"$2\")"
}
Array.remove () 
{ 
    readarray -t "$1" < <(PrintEvalArray "$1" | RemoveMatchLine "$2")
}
Array.rev () 
{ 
    readarray -t "$1" < <(PrintEvalArray "$1" | tac)
}
Array.shift () 
{ 
    readarray -t "$1" < <(PrintEvalArray "$1" | sed "1,${2-"1"}d")
}
Array.eval () 
{ 
    eval "PrintArray \"\${$1[@]}\""
}
Array.print () 
{ 
    (( $# >= 1 )) || return 0;
    printf "%s\n" "${@}"
}
Array.indexOf () 
{ 
    local n=();
    readarray -t n < <(grep -x -n "$1" | cut -d ":" -f 1 | ForEach eval echo '$(( {} - 1 ))');
    (( "${#n[@]}" >= 1 )) || return 1;
    PrintArray "${n[@]}";
    return 0
}
Array.length () 
{ 
    PrintEvalArray "$1" | wc -l
}
Array.forEach () 
{ 
    PrintEvalArray "$1" | ForEach "${@:2}"
}
Array.includes () 
{ 
    PrintEvalArray "$1" | grep -qx "$2"
}
