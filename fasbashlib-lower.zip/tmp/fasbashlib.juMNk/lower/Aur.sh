#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all
declare -r FSBLIB_LIBLIST=("Aur" )
declare -r FSBLIB_VERSION='v0.2.3.r398.gaac1940-lower'
declare -r FSBLIB_REQUIRE='ModernBash'
Aur.checkJson () 
{ 
    local _ResultCount _Json _Type;
    _Json="$(cat)";
    _ResultCount=$(jq -r ".resultcount" <<< "$_Json");
    _Type=$(jq -r ".type" <<< "$_Json");
    (( _ResultCount > 0 )) && [[ "$_Type" != "error" ]] && { 
        jq -r ".results[]" <<< "$_Json";
        return 0
    };
    return 1
}
Aur.getAllDepends () 
{ 
    jq -r ".Depends[], .MakeDepends[]"
}
Aur.getDepends () 
{ 
    jq -r ".Depends[]"
}
Aur.getDescription () 
{ 
    jq -r ".Description"
}
Aur.getFirstSubmitted () 
{ 
    jq -r ".FirstSubmitted"
}
Aur.getID () 
{ 
    jq -r ".ID"
}
Aur.getInfo () 
{ 
    GetRawAurInfo "$1" | Aur.checkJson
}
Aur.getKeywords () 
{ 
    jq -r ".Keywords[]"
}
Aur.getLastModified () 
{ 
    jq -r ".LastModified"
}
Aur.getLicense () 
{ 
    jq -r ".License[]"
}
Aur.getMaintainer () 
{ 
    jq -r ".Maintainer"
}
Aur.getMakeDepends () 
{ 
    jq -r ".MakeDepends[]"
}
Aur.getNumVotes () 
{ 
    jq -r ".NumVotes"
}
Aur.getOptDepends () 
{ 
    jq -r ".OptDepends[]"
}
Aur.getPackageBase () 
{ 
    jq -r ".PackageBase"
}
Aur.getPackageBaseID () 
{ 
    jq -r ".PackageBaseID"
}
Aur.getPopularity () 
{ 
    jq -r ".Popularity"
}
Aur.getRawInfo () 
{ 
    curl -sL "https://aur.archlinux.org/rpc?v=5&type=info&arg=${1}"
}
Aur.getRecursiveDepends () 
{ 
    local _Pkg;
    _Pkg="$(Pm.GetName <<< "$1")";
    _AurDependList=();
    export FSBLIB_CACHEID="FasBashLib_Aur";
    ExistCache "InstalledPackage" || RunPacman -Qq | CreateCache "InstalledPackage" > /dev/null;
    ExistCache "RepoPackage" || GetPacmanRepoPkgList | CreateCache "RepoPackage" > /dev/null;
    function _Resolve () 
    { 
        GetCache "RepoPackage" | grep -qx "$1" && return 0;
        while read -r _P; do
            ArrayIncludes _AurDependList "$_P" && continue;
            GetCache "RepoPackage" | grep -qx "$_P" && continue;
            _AurDependList+=("$_P");
            _Resolve "$_P";
        done < <(Aur.getInfo "$1" | Aur.getAllDepends | Pm.GetName)
    };
    _Resolve "$_Pkg";
    PrintEvalArray _AurDependList
}
Aur.getSearch () 
{ 
    local _Field="${1-"name-desc"}" _Keywords="$2";
    curl -sL "https://aur.archlinux.org/rpc?v=5&type=search&by=$_Field&arg=${_Keywords}" | Aur.checkJson
}
Aur.getURL () 
{ 
    jq -r ".URL"
}
Aur.getURLPath () 
{ 
    jq -r ".URLPath"
}
Aur.getVersion () 
{ 
    jq -r ".Version"
}
Aur.infoToBash () 
{ 
    local _Prefix="${AurPrefix-"{}"}" _Json;
    local _ArrName _VarName;
    _Json="$(cat)";
    for _JsonKey in "Depends" "Keywords" "License" "MakeDepends" "OptDepends";
    do
        _ArrName=$(sed "s|{}|$_JsonKey|g" <<< "$_Prefix");
        echo "${_ArrName}=($(Aur.Get$_JsonKey <<< "$_Json" | sed "s|^|\"|g; s|$|\" |g" | tr -d "\n"))";
    done;
    for _JsonKey in "Description" "FirstSubmitted" "ID" "LastModified" "Maintainer" "NumVotes" "PackageBase" "PackageBaseID" "Popularity" "URL" "URLPath" "Version";
    do
        _VarName=$(sed "s|{}|$_JsonKey|g" <<< "$_Prefix");
        echo "${_VarName}=\"$(Aur.Get$_JsonKey <<< "$_Json")\"";
    done
}
Aur.isPkgOutOfDated () 
{ 
    local _Status;
    _Status=$(jq -r ".OutOfDate");
    case "$_Status" in 
        "null")
            return 1
        ;;
        *)
            echo "$_Status";
            return 0
        ;;
    esac
}
