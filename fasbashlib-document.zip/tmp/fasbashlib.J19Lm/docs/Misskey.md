
# Misskey

MisskeyのAPIをシェルスクリプトで扱うためのバインディング

## Overview

curlとjqを利用してMisskeyのAPIを操作するための関数です。

Stream APIは現在非対応です。

実装済みのAPIは非常に少ないですがBindingBase関数で簡単に実装可能です。



