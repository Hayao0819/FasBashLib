
# Aur

AurのAPIを使用します

## Overview

AurwebのAPIをcurlを使って呼び出し、必要な情報を取得します



