
# Readlink

Readlink -fと同等の機能を実装した関数

## Overview

readlink -fをシェルスクリプトで再実装した関数です。

これらのコードは [ko1nksm/readlinkf](https://github.com/ko1nksm/readlinkf) から引用しています。

一部インデントやコードを改変して使用させていただいています。ありがとうございます。



