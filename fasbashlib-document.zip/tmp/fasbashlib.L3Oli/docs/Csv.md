
# Csv

Csvファイルを解析します

## Overview

Csvファイルを解析してシェルスクリプト内で扱えるようにします
`CSVDELIM 変数でCSVの区切りを制御できます`



