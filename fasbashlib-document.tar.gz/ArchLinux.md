
# Mkinitcpio.sh

Mkinitcpioに関するBash関数

## Overview

以下のmkinitcpioに関連した関数を提供します
* GetMkinitcpioPresetList
* GetKernelFileList
* GetKernelSrcList



