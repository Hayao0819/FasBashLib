#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all
declare -r FSBLIB_LIBLIST=("Message" )
declare -r FSBLIB_VERSION='v0.2.3.r413.g016cfd1-snake'
declare -r FSBLIB_REQUIRE='Any'
msg.common () 
{ 
    local i l="$1" string="$2" out="${3-""}";
    shift 2 || return 1;
    { 
        [[ -z "${out-""}" ]] && { 
            [[ "${l^^}" = *"ERR"* ]] || [[ "${l^^}" = *"WARN"* ]] || [[ "${l^^}" = *"DEBUG"* ]]
        }
    } && out="stderr";
    case "${FSBLIB_MSG-"${out:-"stdout"}"}" in 
        "stdout")
            for i in $(seq "$(echo -e "${string}" | wc -l)");
            do
                echo -n "$l ";
                echo -e "${string}" | head -n "${i}" | tail -n 1;
            done
        ;;
        "stderr")
            for i in $(seq "$(echo -e "${string}" | wc -l)");
            do
                echo -n "$l " 1>&2;
                echo -e "${string}" | head -n "${i}" | tail -n 1 1>&2;
            done
        ;;
    esac
}
msg.debug () 
{ 
    msg.common "Debug:" "${*}" stderr
}
msg.err () 
{ 
    msg.common "Error:" "${*}" stderr
}
msg.info () 
{ 
    msg.common " Info:" "${*}" stdout
}
msg.warn () 
{ 
    msg.common " Warn:" "${*}" stderr
}
