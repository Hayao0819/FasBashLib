#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_VERSION="v0.2.3.r300.gac11343-snake"
FSBLIB_REQUIRE="ModernBash"

url.authority () 
{ 
    local i _NoScheme;
    while read -r i; do
        _NoScheme=$(url.no_scheme <<< "$i");
        [[ "$_NoScheme" == "//"* ]] || return 1;
        cut -d "/" -f 1 < <(sed "s|^//||g" <<< "$_NoScheme");
    done
}
url.fragment () 
{ 
    local i;
    i="$(url.path_and_query_and_fragment)";
    [[ "$i" == *"#"* ]] || return 0;
    cut -d "#" -f 2- <<< "$i"
}
url.host () 
{ 
    url.authority | cut -d "@" -f 2- | cut -d ":" -f 1
}
url.no_scheme () 
{ 
    cut -d ":" -f 2-
}
url.path () 
{ 
    url.path_and_query_and_fragment | cut -d "#" -f 1 | cut -d "?" -f 1
}
url.path_and_query_and_fragment () 
{ 
    local i;
    while read -r i; do
        sed "s|^//$(url.authority <<< "$i")||g" <<< "$(url.no_scheme <<< "$i")";
    done
}
url.port () 
{ 
    local i;
    while read -r i; do
        [[ "$i" == *":"* ]] || { 
            continue
        };
        cut -d ":" -f 2 <<< "$i";
    done < <(url.authority)
}
url.query () 
{ 
    local i;
    while read -r i; do
        url.path_and_query_and_fragment <<< "$i" | sed "s|#$(url.fragment <<< "$i")||g" | cut -d "?" -f 2-;
    done
}
url.scheme () 
{ 
    cut -d ":" -f 1
}
url.user () 
{ 
    local i;
    while read -r i; do
        [[ "$i" == *"@"* ]] || { 
            echo "";
            continue
        };
        cut -d "@" -f 1 <<< "$i";
    done < <(url.authority)
}
url.has_authority () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(url.no_scheme <<< "$i")" = "//"* ]]
}
url.has_fragment () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(url.path_and_query_and_fragment <<< "$i")" = *"#"* ]]
}
url.has_port () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(url.authority <<< "$i")" = *":"* ]]
}
url.has_query () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(url.path_and_query_and_fragment <<< "$i")" = *"?"* ]]
}
url.has_user () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(url.authority <<< "$i")" = *"@"* ]]
}
url.parse () 
{ 
    local i="${1-""}";
    if [[ -z "${i}" ]]; then
        read -r i;
    fi;
    url.scheme <<< "$i";
    echo ":";
    if url.has_authority "$i"; then
        if url.has_user "$i"; then
            url.user <<< "$i";
            echo "@";
        fi;
        url.host <<< "$i";
        if url.has_port "$i"; then
            echo ":";
            url.port <<< "$i";
        fi;
    fi;
    url.path <<< "$i";
    if url.has_fragment "$i"; then
        echo "#";
        url.fragment <<< "$i";
    fi;
    if url.has_query "$i"; then
        echo "?";
        url.query <<< "$i";
    fi
}
url.get_query () 
{ 
    grep "^ *$1=" | cut -d "=" -f 2-
}
url.parse_query () 
{ 
    local i="${1-""}";
    if [[ -z "${i}" ]]; then
        read -r i;
    fi;
    if grep -q "[a-zA-Z]://" <<< "$i"; then
        i="$(url.query <<< "$i")";
    fi;
    i="$(sed "s|^\?||g" <<< "$i")";
    tr "&" "\n" <<< "$i" | cut -d "#" -f 1
}
