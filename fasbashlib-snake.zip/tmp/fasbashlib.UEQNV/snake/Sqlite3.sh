#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

declare -r FSBLIB_VERSION="v0.2.3.r368.g43eacfc-snake"
declare -r FSBLIB_REQUIRE="ModernBash"


sqlite3.call () 
{ 
    Msg.Debug sqlite3 "$SQLITE3_DBPATH" "$@" 1>&2;
    sqlite3 "${SQLITE3_OPTIONS[@]}" "$SQLITE3_DBPATH" "$@"
}
sqlite3.connect () 
{ 
    export SQLITE3_DBPATH="$1";
    echo ".open \"$SQLITE3_DBPATH\"" | sqlite3;
    return 0
}
sqlite3.create () 
{ 
    local _table="$1" _args=() _columns=();
    shift 1 || return 1;
    _columns=("$@");
    _args+=(create table "$_table" "(");
    ForEach eval "_args+=(\"\\\"{}\\\"\" ,)" < <(PrintEvalArray _columns);
    Array.Pop _args;
    _args+=(")");
    sqlite3.call "${_args[*]}"
}
sqlite3.current_db () 
{ 
    if [[ -z "${SQLITE3_DBPATH-""}" ]]; then
        Msg.Err "No datebase is connected.";
        return 1;
    fi;
    echo "${SQLITE3_DBPATH}";
    return 0
}
sqlite3.delete () 
{ 
    local _table="$1" _args=();
    shift 1 || return 1;
    if (( $# < 1 )) && (( ${SQLITE3_ALLOWDELETEALL-"0"} != 1 )); then
        Msg.Err "Cannot delete all data.\nIf you really want that, Please set environment-variable \"SQLITE3_ALLOWDELETEALL=1\"";
        return 1;
    fi;
    _args+=(delete from "$_table");
    if (( $# > 0)); then
        _args+=(where "${@}");
    fi;
    sqlite3.call "${_args[*]}"
}
sqlite3.exist_field () 
{ 
    _result="$(sqlite3.call "SELECT * FROM '$1' WHERE $2 = '$3' LIMIT 1;")";
    if [[ -n "${_result-""}" ]]; then
        return 0;
    fi;
    return 1
}
sqlite3.exist_table () 
{ 
    local _result;
    _result="$(sqlite3.call                             "SELECT COUNT(*) 
                            FROM sqlite_master 
                            WHERE TYPE='table' AND name='$1';
            ")";
    if (( _result > 0 )); then
        return 0;
    fi;
    return 1
}
sqlite3.insert () 
{ 
    local _table="$1" _args=();
    shift 1 || return 1;
    local _values=("$@");
    _args+=(insert into "$_table" values '(');
    ForEach eval "_args+=(\"\\\"{}\\\"\" ,)" < <(PrintEvalArray _values);
    Array.Pop _args;
    _args+=(");");
    sqlite3.call "${_args[*]}"
}
sqlite3.select () 
{ 
    local _table="$1" _args=();
    shift 1 || return 1;
    local _values=("$@");
    _args+=(select);
    ForEach eval "_args+=(\"\\\"{}\\\"\" ,)" < <(PrintEvalArray _values);
    Array.Pop _args;
    _args+=("from" "$_table" ";");
    sqlite3.call "${_args[*]}"
}
sqlite3.select_all () 
{ 
    local _table="$1" _args=();
    shift 1 || return 1;
    sqlite3.call "select * from $_table"
}
