#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

declare -r FSBLIB_VERSION="v0.2.3.r380.gbbcc054-snake"
declare -r FSBLIB_REQUIRE="ModernBash"


aur.check_json () 
{ 
    local _ResultCount _Json _Type;
    _Json="$(cat)";
    _ResultCount=$(jq -r ".resultcount" <<< "$_Json");
    _Type=$(jq -r ".type" <<< "$_Json");
    (( _ResultCount > 0 )) && [[ "$_Type" != "error" ]] && { 
        jq -r ".results[]" <<< "$_Json";
        return 0
    };
    return 1
}
aur.get_all_depends () 
{ 
    jq -r ".Depends[], .MakeDepends[]"
}
aur.get_depends () 
{ 
    jq -r ".Depends[]"
}
aur.get_description () 
{ 
    jq -r ".Description"
}
aur.get_first_submitted () 
{ 
    jq -r ".FirstSubmitted"
}
aur.get_id () 
{ 
    jq -r ".ID"
}
aur.get_info () 
{ 
    GetRawAurInfo "$1" | aur.check_json
}
aur.get_keywords () 
{ 
    jq -r ".Keywords[]"
}
aur.get_last_modified () 
{ 
    jq -r ".LastModified"
}
aur.get_license () 
{ 
    jq -r ".License[]"
}
aur.get_maintainer () 
{ 
    jq -r ".Maintainer"
}
aur.get_make_depends () 
{ 
    jq -r ".MakeDepends[]"
}
aur.get_num_votes () 
{ 
    jq -r ".NumVotes"
}
aur.get_opt_depends () 
{ 
    jq -r ".OptDepends[]"
}
aur.get_package_base () 
{ 
    jq -r ".PackageBase"
}
aur.get_package_base_id () 
{ 
    jq -r ".PackageBaseID"
}
aur.get_popularity () 
{ 
    jq -r ".Popularity"
}
aur.get_raw_info () 
{ 
    curl -sL "https://aur.archlinux.org/rpc?v=5&type=info&arg=${1}"
}
aur.get_recursive_depends () 
{ 
    local _Pkg;
    _Pkg="$(Pm.GetName <<< "$1")";
    _AurDependList=();
    export FSBLIB_CACHEID="FasBashLib_Aur";
    ExistCache "InstalledPackage" || RunPacman -Qq | CreateCache "InstalledPackage" > /dev/null;
    ExistCache "RepoPackage" || GetPacmanRepoPkgList | CreateCache "RepoPackage" > /dev/null;
    function _Resolve () 
    { 
        GetCache "RepoPackage" | grep -qx "$1" && return 0;
        while read -r _P; do
            ArrayIncludes _AurDependList "$_P" && continue;
            GetCache "RepoPackage" | grep -qx "$_P" && continue;
            _AurDependList+=("$_P");
            _Resolve "$_P";
        done < <(aur.get_info "$1" | aur.get_all_depends | Pm.GetName)
    };
    _Resolve "$_Pkg";
    PrintEvalArray _AurDependList
}
aur.get_search () 
{ 
    local _Field="${1-"name-desc"}" _Keywords="$2";
    curl -sL "https://aur.archlinux.org/rpc?v=5&type=search&by=$_Field&arg=${_Keywords}" | aur.check_json
}
aur.get_ur_l () 
{ 
    jq -r ".URL"
}
aur.get_ur_lpath () 
{ 
    jq -r ".URLPath"
}
aur.get_version () 
{ 
    jq -r ".Version"
}
aur.info_to_bash () 
{ 
    local _Prefix="${AurPrefix-"{}"}" _Json;
    local _ArrName _VarName;
    _Json="$(cat)";
    for _JsonKey in "Depends" "Keywords" "License" "MakeDepends" "OptDepends";
    do
        _ArrName=$(sed "s|{}|$_JsonKey|g" <<< "$_Prefix");
        echo "${_ArrName}=($(Aur.Get$_JsonKey <<< "$_Json" | sed "s|^|\"|g; s|$|\" |g" | tr -d "\n"))";
    done;
    for _JsonKey in "Description" "FirstSubmitted" "ID" "LastModified" "Maintainer" "NumVotes" "PackageBase" "PackageBaseID" "Popularity" "URL" "URLPath" "Version";
    do
        _VarName=$(sed "s|{}|$_JsonKey|g" <<< "$_Prefix");
        echo "${_VarName}=\"$(Aur.Get$_JsonKey <<< "$_Json")\"";
    done
}
aur.is_pkg_out_of_dated () 
{ 
    local _Status;
    _Status=$(jq -r ".OutOfDate");
    case "$_Status" in 
        "null")
            return 1
        ;;
        *)
            echo "$_Status";
            return 0
        ;;
    esac
}
