#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Esc")
FSBLIB_FUNCLIST+=("Esc.ClearLeft" "Esc.ClearLine" "Esc.ClearRight" "Esc.ClearScreen" "Esc.MoveCursor" "Esc.MoveCursorDown" "Esc.MoveCursorLeft" "Esc.MoveCursorRight" "Esc.MoveCursorUp" "Esc.ClearUpperLines" "Esc.BlackBackground" "Esc.BlackText" "Esc.Blink" "Esc.BlueBackground" "Esc.BlueText" "Esc.Bold" "Esc.Conceal" "Esc.CrossedOut" "Esc.CyanBackground" "Esc.CyanText" "Esc.GreenBackground" "Esc.GreenText" "Esc.Italic" "Esc.LowIntensity" "Esc.MagentaBackground" "Esc.MagentaText" "Esc.RapidBlink" "Esc.RedBackground" "Esc.RedText" "Esc.ResetStyle" "Esc.Reverse" "Esc.Underline" "Esc.WhiteBackground" "Esc.WhiteText" "Esc.YellowBackground" "Esc.YellowText")
FSBLIB_VERSION='v0.2.6.r403.gba569b1-upper'
FSBLIB_REQUIRE='Any'

Esc.ClearLeft() {
	printf "\033[1K"
}
Esc.ClearLine() {
	printf "\033[2K"
}
Esc.ClearRight() {
	printf "\033[0K"
}
Esc.ClearScreen() {
	printf "\033[2J"
}
Esc.MoveCursor() {
	printf "\033[%d;%dH" "$1" "$2"
}
Esc.MoveCursorDown() {
	printf "\033[%dB" "$1"
}
Esc.MoveCursorLeft() {
	printf "\033[%dD" "$1"
}
Esc.MoveCursorRight() {
	printf "\033[%dC" "$1"
}
Esc.MoveCursorUp() {
	printf "\033[%dA" "$1"
}
Esc.ClearUpperLines() {
	for i in $(seq 1 "$1"); do
		Esc.MoveCursorUp 1
		Esc.ClearLine
	done
}
Esc.BlackBackground() {
	printf "\033[40m"
}
Esc.BlackText() {
	printf "\033[30m"
}
Esc.Blink() {
	printf "\033[5m"
}
Esc.BlueBackground() {
	printf "\033[44m"
}
Esc.BlueText() {
	printf "\033[34m"
}
Esc.Bold() {
	printf "\033[1m"
}
Esc.Conceal() {
	printf "\033[8m"
}
Esc.CrossedOut() {
	printf "\033[9m"
}
Esc.CyanBackground() {
	printf "\033[46m"
}
Esc.CyanText() {
	printf "\033[36m"
}
Esc.GreenBackground() {
	printf "\033[42m"
}
Esc.GreenText() {
	printf "\033[32m"
}
Esc.Italic() {
	printf "\033[3m"
}
Esc.LowIntensity() {
	printf "\033[2m"
}
Esc.MagentaBackground() {
	printf "\033[45m"
}
Esc.MagentaText() {
	printf "\033[35m"
}
Esc.RapidBlink() {
	printf "\033[6m"
}
Esc.RedBackground() {
	printf "\033[41m"
}
Esc.RedText() {
	printf "\033[31m"
}
Esc.ResetStyle() {
	printf "\033[0m"
}
Esc.Reverse() {
	printf "\033[7m"
}
Esc.Underline() {
	printf "\033[4m"
}
Esc.WhiteBackground() {
	printf "\033[47m"
}
Esc.WhiteText() {
	printf "\033[37m"
}
Esc.YellowBackground() {
	printf "\033[43m"
}
Esc.YellowText() {
	printf "\033[33m"
}
