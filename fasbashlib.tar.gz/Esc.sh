#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Esc")
FSBLIB_FUNCLIST+=()
FSBLIB_VERSION='v0.2.7.1.r437.g22e9944-upper'
FSBLIB_REQUIRE='ModernBash'

Esc.ClearScreen() {
	printf "\033[2J" >/dev/tty
}
Esc.Return() {
	printf "\r" >/dev/tty
}
Esc.ClearRight() {
	printf "\033[0K" >/dev/tty
}
Esc.ClearLine() {
	printf "\033[2K" >/dev/tty
}
Esc.ClearLeft() {
	printf "\033[1K" >/dev/tty
}
Esc.GetTermX() {
	[[ -n ${COLUMNS-""} ]] && echo "$COLUMNS" && return 0
	tput cols
}
Esc.GetX() {
	local _POS
	printf "\033[6n" >>/dev/tty
	read -r -s -d "R" _POS
	echo $(("$(printf "%s\n" "${_POS:2}" | cut -d";" -f2)" - 1))
}
Esc.MoveCursorLeft() {
	printf "\033[%dD" "$1" >/dev/tty
}
Esc.GetY() {
	local _POS
	printf "\033[6n" >>/dev/tty
	read -r -s -d "R" _POS
	echo $(("$(printf "%s\n" "${_POS:2}" | cut -d";" -f1)" - 1))
}
Esc.MoveCursorRight() {
	printf "\033[%dC" "$1" >/dev/tty
}
Esc.GetTermY() {
	[[ -n ${LINES-""} ]] && echo "$LINES" && return 0
	tput lines
}
Esc.MoveCursorUp() {
	printf "\033[%dA" "$1" >/dev/tty
}
Esc.MoveCursorDown() {
	printf "\033[%dB" "$1" >/dev/tty
}
Esc.MoveCursor() {
	printf "\033[%d;%dH" "$1" "$2" >/dev/tty
}
Esc.ClearUpperLines() {
	for i in $(seq 1 "$1"); do
		Esc.MoveCursorUp 1
		Esc.ClearLine
	done
}
Esc.ClearLineAndReturn() {
	Esc.ClearLine
	Esc.Return
}
Esc.Bold() {
	printf "\033[1m" >/dev/tty
}
Esc.RapidBlink() {
	printf "\033[6m" >/dev/tty
}
Esc.RedText() {
	printf "\033[31m" >/dev/tty
}
Esc.WhiteText() {
	printf "\033[37m" >/dev/tty
}
Esc.YellowText() {
	printf "\033[33m" >/dev/tty
}
Esc.CyanBackground() {
	printf "\033[46m" >/dev/tty
}
Esc.Reverse() {
	printf "\033[7m" >/dev/tty
}
Esc.BlackBackground() {
	printf "\033[40m" >/dev/tty
}
Esc.Blink() {
	printf "\033[5m" >/dev/tty
}
Esc.MagentaText() {
	printf "\033[35m" >/dev/tty
}
Esc.Underline() {
	printf "\033[4m" >/dev/tty
}
Esc.WhiteBackground() {
	printf "\033[47m" >/dev/tty
}
Esc.GreenText() {
	printf "\033[32m" >/dev/tty
}
Esc.RedBackground() {
	printf "\033[41m" >/dev/tty
}
Esc.ResetStyle() {
	printf "\033[0m" >/dev/tty
}
Esc.LowIntensity() {
	printf "\033[2m" >/dev/tty
}
Esc.GreenBackground() {
	printf "\033[42m" >/dev/tty
}
Esc.CrossedOut() {
	printf "\033[9m" >/dev/tty
}
Esc.MagentaBackground() {
	printf "\033[45m" >/dev/tty
}
Esc.BlackText() {
	printf "\033[30m" >/dev/tty
}
Esc.BlueText() {
	printf "\033[34m" >/dev/tty
}
Esc.CyanText() {
	printf "\033[36m" >/dev/tty
}
Esc.Conceal() {
	printf "\033[8m" >/dev/tty
}
Esc.Italic() {
	printf "\033[3m" >/dev/tty
}
Esc.YellowBackground() {
	printf "\033[43m" >/dev/tty
}
Esc.BlueBackground() {
	printf "\033[44m" >/dev/tty
}
