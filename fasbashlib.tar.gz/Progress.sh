#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Progress")
FSBLIB_FUNCLIST+=("Prog.Bar" "Prog.Kill" "Prog.Rotation")
FSBLIB_VERSION='v0.2.6.r416.g777fb50-upper'
FSBLIB_REQUIRE='ModernBash'
FSBLIB_PROG_PIDFILEPATH='FSBLIB_PROGRESS_PIDLIST'

Prog.Bar() {
	local Max="$1" Counter="$2"
	local SharpCount=$((Counter * 100 / Max))
	local SpaceCount=$((100 - SharpCount))
	Esc.Return
	if ((Counter == 0)); then
		echo -n "$Counter/$Max [$(yes " " | head -n "$Max" | tr -d "\n")]"
	else
		echo -n "$Counter/$Max [$(yes "#" | head -n "$SharpCount" | tr -d "\n")$(yes " " | head -n "$SpaceCount" | tr -d "\n")]"
	fi
}
Prog.Kill() {
	local AnimeID="${1-""}"
	[[ -z ${AnimeID} ]] && return 1
	local TargetPID
	TargetPID="$(grep -o "$$-${AnimeID}=[0-9]*" "$TMPDIR/${FSBLIB_PROG_PIDFILEPATH}" | cut -d "=" -f 2)"
	[[ -n ${TargetPID} ]] && kill -9 "${TargetPID}"
}
Prog.Rotation() {
	local Chr AnimeID="${1-""}"
	[[ -z ${AnimeID} ]] && return 1
	[[ -n ${2-""} ]] && echo -n "${2}" 1>&2
	echo "${$}-${AnimeID}=$BASHPID" >>"$TMPDIR/$FSBLIB_PROG_PIDFILEPATH"
	while true; do
		for Chr in "-" '\' "|" "/"; do
			printf "%s" "$Chr" 1>&2
			sleep 0.1
			Esc.MoveCursorLeft 1
		done
	done
}
