#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Pacman")
FSBLIB_FUNCLIST+=("pm.check_pkg" "pm.get_config" "pm.get_installed_pkg_ver" "pm.get_keyring_list" "pm.get_latest_pkg_ver" "pm.get_name" "pm.get_pacman_kernel_pkg" "pm.get_pacman_keyring_dir" "pm.get_repo_conf" "pm.get_repo_list_from_conf" "pm.get_repo_pkg_list" "pm.get_repo_server" "pm.get_repo_ver" "pm.get_root" "pm.is_repo_pkg" "pm.pacman_gpg" "pm.run" "pm.run_key" "pm.get_db_next_section" "pm.get_db_section" "pm.get_db_section_list" "pm.create_db_tmp_dir" "pm.delete_db_tmp_dir" "pm.get_db_tmp_dir" "pm.get_pkg_arch" "pm.get_repo_list_from_local_db" "pm.get_sync_all_desc" "pm.get_sync_db_desc" "pm.get_sync_db_desc_path" "pm.get_virtual_pkg_list" "pm.is_opend_sync_db" "pm.open_sync_db" "pm.opened_sync_db_list" "pm.parse_pkg_file_name")
FSBLIB_VERSION='v0.2.6.r453.g306d487-snake'
FSBLIB_REQUIRE='ModernBash'

pm.check_pkg() {
	local p
	for p in "$@"; do
		pm.run -Qq "$p" >/dev/null 2>&1 || return 1
	done
	return 0
}
pm.get_config() {
	LANG=C pacman-conf --config="${PACMAN_CONF-"/etc/pacman.conf"}" "$@"
}
pm.get_installed_pkg_ver() {
	if [[ -z ${*} ]]; then
		cat
	else
		PrintArray "$@"
	fi | ForEach pacman -Q "{}" | cut -d " " -f 2
	PrintArray "${PIPESTATUS[@]}" | grep -qx "1" && return 1
	return 0
}
pm.get_keyring_list() {
	find "$(@GetKeyringDir)" -name "*.gpg" | GetBaseName | RemoveFileExt
}
pm.get_latest_pkg_ver() {
	local _LANG="${LANG-""}"
	export LANG=C
	if [[ -z ${*} ]]; then
		cat
	else
		PrintArray "$@"
	fi | ForEach pm.run -Si "{}" | grep "^Version" | cut -d ":" -f 2 | RemoveBlank
	[[ -n $_LANG ]] && export LANG="$_LANG"
	return 0
}
pm.get_name() {
	cut -d "<" -f 1 | cut -d ">" -f 1 | cut -d "=" -f 1
}
pm.get_pacman_kernel_pkg() {
	echo "there is nothing"
}
pm.get_pacman_keyring_dir() {
	local _KeyringDir=""
	_KeyringDir="$(LANG=C pacman-key -h | RemoveBlank | grep -A 1 -- "^--populate" | tail -n 1 | cut -d "/" -f 2- | sed "s|'$||g")"
	: "${_KeyringDir="usr/share/pacman/keyrings"}"
	_KeyringDir="$(pm.get_root)/$_KeyringDir"
	_KeyringDir="$(sed -E "s|/+|/|g" <<<"$_KeyringDir")"
	if [[ -e $_KeyringDir ]]; then
		Readlinkf "$_KeyringDir"
	else
		echo "$_KeyringDir"
	fi
}
pm.get_repo_conf() {
	ForEach eval 'echo [{}] && pm.get_config -r {}'
}
pm.get_repo_list_from_conf() {
	pm.get_config --repo-list
}
pm.get_repo_pkg_list() {
	pm.run -Slq "$@"
}
pm.get_repo_server() {
	ForEach eval 'pm.get_config -r {}' | grep "^Server" | ForEach eval "Ini.ParseLine <<< '{}' ; printf '%s\n' \${VALUE}"
}
pm.get_repo_ver() {
	pm.run -Sp --print-format '%v' "$1"
}
pm.get_root() {
	pm.get_config RootDir
}
pm.is_repo_pkg() {
	pm.run -Slq | grep -qx "$(pm.get_name <<<"$1")"
}
pm.pacman_gpg() {
	gpg --homedir "$(pm.get_config GPGDir)" "$@"
}
pm.run() {
	pacman --noconfirm --config "${PACMAN_CONF-"/etc/pacman.conf"}" "$@"
}
pm.run_key() {
	pacman-key --config "${PACMAN_CONF-"/etc/pacman.conf"}" "$@"
}
pm.get_db_next_section() {
	pm.get_db_section_list | grep -x -A 1 "^%$1%$" | GetLine 2 | sed "s|^%||g; s|%$||g"
}
pm.get_db_section() {
	readarray -t _Stdin
	PrintArray "${_Stdin[@]}" | sed -ne "/^%$1%$/,/^%$(PrintEvalArray _Stdin | pm.get_db_next_section "$1")%$/p" | sed '1d; $d'
}
pm.get_db_section_list() {
	grep -E "^%.*%$"
}
pm.create_db_tmp_dir() {
	mkdir -p "$(pm.get_db_tmp_dir)"
}
pm.delete_db_tmp_dir() {
	rm -rf "$(pm.get_db_tmp_dir)"
}
pm.get_db_tmp_dir() {
	echo "${TMPDIR-"/tmp"}/fasbashlib-pacman-db"
}
pm.get_pkg_arch() {
	pm.get_sync_db_desc "$1" | pm.get_db_section ARCH | RemoveBlank
}
pm.get_repo_list_from_local_db() {
	find "$(pm.get_config DBPath)/sync" -mindepth 1 -maxdepth 1 -type f | GetBaseName | sed "s|.db$||g"
	return 0
}
pm.get_sync_all_desc() {
	find "$(pm.get_db_tmp_dir)" -mindepth 3 -maxdepth 3 -name "desc" -type f
}
pm.get_sync_db_desc() {
	local _path
	_path="$(pm.get_sync_db_desc_path "$1")"
	[[ -e $_path ]] || return 1
	cat "$_path/desc"
}
pm.get_sync_db_desc_path() {
	local _repo
	_repo="$(pacman -Sp --print-format '%r' "$1")"
	{
		IsPacmanSyncDbOpend "$_repo" || OpenPacmanSyncDb "$_repo"
	} || return 1
	echo "$(pm.get_db_tmp_dir)/sync/$(pacman -Sp --print-format '%r/%n-%v' "$1")"
}
pm.get_virtual_pkg_list() {
	pm.get_repo_list_from_local_db | ForEach pm.open_sync_db {}
	pm.get_sync_all_desc | ForEach eval "pm.get_db_section PROVIDES < {}" | RemoveBlank
}
pm.is_opend_sync_db() {
	readarray -t _PkgDbList < <(find "$(pm.get_db_tmp_dir)/sync/$1" -mindepth 1 -maxdepth 1 -type d)
	(("${#_PkgDbList[@]}" > 0)) && return 0
	return 1
}
pm.open_sync_db() {
	local _Dir _RepoDb
	pm.create_db_tmp_dir
	_Dir="$(pm.get_db_tmp_dir)/sync/$1"
	mkdir -p "$_Dir"
	_RepoDb="$(pm.get_config DBPath)/sync/$1.db"
	[[ -e $_RepoDb ]] || return 1
	tar -xzf "${_RepoDb}" -C "$_Dir" || return 1
}
pm.opened_sync_db_list() {
	find "$(pm.get_db_tmp_dir)/sync/" -mindepth 1 -maxdepth 1 -type d
}
pm.parse_pkg_file_name() {
	local _Pkg="$1"
	local _PkgName _PkgVer _PkgRel _Arch _FileExt
	local _PkgWithOutExt
	if grep "/" <<<"$_Pkg"; then
		_Pkg="$(basename "$_Pkg")"
	fi
	_FileExt="$(GetLastSplitString "-" "$_Pkg" | cut -d "." -f 2-)"
	_PkgWithOutExt="${_Pkg%%".${_FileExt}"}"
	_Arch=$(GetLastSplitString "-" "${_PkgWithOutExt}")
	_PkgRel=$(GetLastSplitString "-" "${_PkgWithOutExt%%"-${_Arch}"}")
	_PkgVer=$(GetLastSplitString "-" "${_PkgWithOutExt%%"-${_PkgRel}-${_Arch}"}")
	_PkgName="${_PkgWithOutExt%%"-${_PkgVer}-${_PkgRel}-${_Arch}"}"
	_ParsedPkg=("${_PkgName}" "-" "$_PkgVer" "-" "$_PkgRel" "-" "$_Arch" ".$_FileExt")
	if [[ ! "$(PrintArray "${_ParsedPkg[@]}" | tr -d "\n")" == "${_Pkg}" ]]; then
		return 1
	fi
	PrintArray "${_ParsedPkg[@]}"
}
