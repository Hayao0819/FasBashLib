#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Esc")
FSBLIB_FUNCLIST+=("esc.clear_left" "esc.clear_line" "esc.clear_line_and_return" "esc.clear_right" "esc.clear_screen" "esc.return" "esc.get_term_x" "esc.get_term_y" "esc.get_x" "esc.get_y" "esc.move_cursor" "esc.move_cursor_down" "esc.move_cursor_left" "esc.move_cursor_right" "esc.move_cursor_up" "esc.clear_upper_lines" "esc.black_background" "esc.black_text" "esc.blink" "esc.blue_background" "esc.blue_text" "esc.bold" "esc.conceal" "esc.crossed_out" "esc.cyan_background" "esc.cyan_text" "esc.green_background" "esc.green_text" "esc.italic" "esc.low_intensity" "esc.magenta_background" "esc.magenta_text" "esc.rapid_blink" "esc.red_background" "esc.red_text" "esc.reset_style" "esc.reverse" "esc.underline" "esc.white_background" "esc.white_text" "esc.yellow_background" "esc.yellow_text")
FSBLIB_VERSION='v0.2.7.r409.g4dbfe23-snake'
FSBLIB_REQUIRE='ModernBash'

esc.clear_left() {
	printf "\033[1K"
}
esc.clear_line() {
	printf "\033[2K"
}
esc.clear_line_and_return() {
	esc.clear_line
	esc.return
}
esc.clear_right() {
	printf "\033[0K"
}
esc.clear_screen() {
	printf "\033[2J"
}
esc.return() {
	printf "\r"
}
esc.get_term_x() {
	[[ -n ${COLUMNS-""} ]] && echo "$COLUMNS" && return 0
	tput cols
}
esc.get_term_y() {
	[[ -n ${LINES-""} ]] && echo "$LINES" && return 0
	tput lines
}
esc.get_x() {
	local _POS
	printf "\033[6n" >>/dev/tty
	read -r -s -d "R" _POS
	echo $(("$(printf "%s\n" "${_POS:2}" | cut -d";" -f2)" - 1))
}
esc.get_y() {
	local _POS
	printf "\033[6n" >>/dev/tty
	read -r -s -d "R" _POS
	echo $(("$(printf "%s\n" "${_POS:2}" | cut -d";" -f1)" - 1))
}
esc.move_cursor() {
	printf "\033[%d;%dH" "$1" "$2"
}
esc.move_cursor_down() {
	printf "\033[%dB" "$1"
}
esc.move_cursor_left() {
	printf "\033[%dD" "$1"
}
esc.move_cursor_right() {
	printf "\033[%dC" "$1"
}
esc.move_cursor_up() {
	printf "\033[%dA" "$1"
}
esc.clear_upper_lines() {
	for i in $(seq 1 "$1"); do
		esc.move_cursor_up 1
		esc.clear_line
	done
}
esc.black_background() {
	printf "\033[40m"
}
esc.black_text() {
	printf "\033[30m"
}
esc.blink() {
	printf "\033[5m"
}
esc.blue_background() {
	printf "\033[44m"
}
esc.blue_text() {
	printf "\033[34m"
}
esc.bold() {
	printf "\033[1m"
}
esc.conceal() {
	printf "\033[8m"
}
esc.crossed_out() {
	printf "\033[9m"
}
esc.cyan_background() {
	printf "\033[46m"
}
esc.cyan_text() {
	printf "\033[36m"
}
esc.green_background() {
	printf "\033[42m"
}
esc.green_text() {
	printf "\033[32m"
}
esc.italic() {
	printf "\033[3m"
}
esc.low_intensity() {
	printf "\033[2m"
}
esc.magenta_background() {
	printf "\033[45m"
}
esc.magenta_text() {
	printf "\033[35m"
}
esc.rapid_blink() {
	printf "\033[6m"
}
esc.red_background() {
	printf "\033[41m"
}
esc.red_text() {
	printf "\033[31m"
}
esc.reset_style() {
	printf "\033[0m"
}
esc.reverse() {
	printf "\033[7m"
}
esc.underline() {
	printf "\033[4m"
}
esc.white_background() {
	printf "\033[47m"
}
esc.white_text() {
	printf "\033[37m"
}
esc.yellow_background() {
	printf "\033[43m"
}
esc.yellow_text() {
	printf "\033[33m"
}
