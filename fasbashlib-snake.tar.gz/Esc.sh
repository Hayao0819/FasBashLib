#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Esc")
FSBLIB_FUNCLIST+=("esc.clear_left" "esc.clear_line" "esc.clear_right" "esc.clear_screen" "esc.move_cursor" "esc.move_cursor_up" "esc.move_cursor_left" "esc.move_cursor_down" "esc.move_cursor_right" "esc.clear_upper_lines" "esc.reset_style")
FSBLIB_VERSION='v0.2.6.r392.ge9679f9-snake'
FSBLIB_REQUIRE='Any'

esc.clear_line() {
	printf "\033[2K"
}
esc.clear_right() {
	printf "\033[0K"
}
esc.clear_left() {
	printf "\033[1K"
}
esc.clear_screen() {
	printf "\033[2J"
}
esc.move_cursor_down() {
	printf "\033[%dB" "$1"
}
esc.move_cursor_right() {
	printf "\033[%dC" "$1"
}
esc.move_cursor() {
	printf "\033[%d;%dH" "$1" "$2"
}
esc.move_cursor_up() {
	printf "\033[%dA" "$1"
}
esc.move_cursor_left() {
	printf "\033[%dD" "$1"
}
esc.clear_upper_lines() {
	for i in $(seq 1 "$1"); do
		esc.move_cursor_up 1
		esc.clear_line
	done
}
esc.reset_style() {
	printf "\033[0m"
}
