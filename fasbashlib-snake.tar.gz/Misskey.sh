#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Misskey")
FSBLIB_FUNCLIST+=("misskey.notes.search" "misskey.notes.create" "misskey.notes.renotes" "misskey.users.get_frequently_replied_users" "misskey.users.notes" "misskey.users.pages" "misskey.users.search_by_username_and_host" "misskey.users.show" "misskey.users.stats" "misskey.admin.server_info" "misskey.setup" "misskey.i" "misskey.meta" "misskey.server_info" "misskey.binding_base" "misskey.send_req" "misskey.make_json" "misskey.is_admin" "misskey.my_id" "misskey.my_name" "misskey.my_user_name")
FSBLIB_VERSION='v0.2.6.r384.g964e537-snake'
FSBLIB_REQUIRE='ModernBash'

misskey.notes.search() {
	misskey.binding_base "notes/search" query limit -- "$@"
}
misskey.notes.create() {
	misskey.binding_base "notes/create" text -- "$@"
}
misskey.notes.renotes() {
	misskey.binding_base "notes/renotes" noteId limit sinceId untilId -- "$@"
}
misskey.users.search_by_username_and_host() {
	misskey.binding_base "users/search-by-username-and-host" username -- "${1:-"$(misskey.my_user_name)"}" "${@:2}"
}
misskey.users.show() {
	misskey.binding_base "users/show" userId -- "${1:-"$(misskey.my_id)"}" "${@:2}"
}
misskey.users.pages() {
	misskey.binding_base "users/pages" userId -- "${1:-"$(misskey.my_id)"}" "${@:2}"
}
misskey.users.notes() {
	misskey.binding_base "users/notes" userId -- "${1:-"$(misskey.my_id)"}" "${@:2}"
}
misskey.users.get_frequently_replied_users() {
	misskey.binding_base "users/get-frequently-replied-users" userId -- "${1:-"$(misskey.my_id)"}" "${@:2}"
}
misskey.users.stats() {
	misskey.binding_base "users/stats" userId -- "${1:-"$(misskey.my_id)"}" "${@:2}"
}
misskey.admin.server_info() {
	misskey.binding_base "/admin/server-info" -- "$@"
}
misskey.setup() {
	export MISSKEY_DOMAIN="${1-"${MISSKEY_DOMAIN-""}"}"
	export MISSKEY_TOKEN="${2-"${MISSKEY_TOKEN-""}"}"
	export MISSKEY_ENTRY="https://${MISSKEY_DOMAIN}/api"
}
misskey.i() {
	misskey.binding_base "/i" -- "$@"
}
misskey.meta() {
	misskey.binding_base "/meta" -- "$@"
}
misskey.server_info() {
	misskey.binding_base "/server-info" -- "$@"
}
misskey.send_req() {
	local _Url="$1" _CurlArgs=()
	shift 1
	_CurlArgs+=(-s -L)
	_CurlArgs+=(-X POST)
	_CurlArgs+=(-H "Content-Type: application/json")
	_CurlArgs+=(-d "$(misskey.make_json "$@")")
	_CurlArgs+=("$_Url")
	Msg.Debug "Run: ${_CurlArgs[*]//"${MISSKEY_TOKEN}"/"TOKEN"}"
	curl "${_CurlArgs[@]}"
}
misskey.make_json() {
	local i _Key _Value
	for i in "i=$MISSKEY_TOKEN" "$@"; do
		_Key=$(cut -d "=" -f 1 <<<"$i")
		_Value=$(cut -d "=" -f 2- <<<"$i")
		if [[ $_Value =~ ^[0-9]+$ ]] || [[ $_Value == true ]] || [[ $_Value == false ]] || [[ $_Value == "{"*"}" ]] || [[ $_Value == "["*"]" ]]; then
			echo -n "{\"$_Key\": $_Value}"
		else
			echo -n "{\"$_Key\": \"$_Value\"}"
		fi
	done | sed "s|}{|,|g" | jq -c -M
}
misskey.binding_base() {
	local _API="$1"
	shift 1
	local i _APIArgs=("") _Args
	for i in "$@"; do
		shift 1 2>/dev/null || true
		if [[ $i == "--" ]]; then
			break
		else
			_APIArgs+=("$i")
		fi
	done
	local _Cnt _Shifted=false
	for ((_Cnt = 1; _Cnt <= "${#_APIArgs[@]} - 1"; _Cnt++)); do
		_Args+=("${_APIArgs[$_Cnt]}=$(eval echo "\${${_Cnt}:-""}")")
		if [[ -z "$(eval echo "\${$((_Cnt + 1)):-""}")" ]]; then
			shift "$_Cnt"
			_Shifted=true
			break
		fi
	done
	if ! Bool _Shifted; then
		_Shifted=true
		shift "$((${#_APIArgs[@]} - 1))"
	fi
	if [[ -z ${MISSKEY_ENTRY-""} ]]; then
		misskey.setup "${MISSKEY_DOMAIN}" "$MISSKEY_TOKEN"
	fi
	misskey.send_req "${MISSKEY_ENTRY%/}/${_API#/}" "${_Args[@]}" "$@"
}
misskey.my_id() {
	misskey.i | jq -r ".id"
}
misskey.is_admin() {
	Bool "$(misskey.i | jq -r ".isAdmin")"
}
misskey.my_user_name() {
	misskey.i | jq -r ".username"
}
misskey.my_name() {
	misskey.i | jq -r ".name"
}
