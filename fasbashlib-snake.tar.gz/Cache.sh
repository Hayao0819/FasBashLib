#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

declare -r FSBLIB_LIBLIST=("Cache")
declare -r FSBLIB_FUNCLIST=("cache.exist" "cache.get" "cache.get_dir" "cache.get_file_last_update" "cache.get_id" "cache.get_time_diff_from_last_update" "cache.create" "cache.create_dir")
declare -r FSBLIB_VERSION='v0.2.5.1.r374.gd1f5152-snake'
declare -r FSBLIB_REQUIRE='ModernBash'

cache.get_file_last_update() {
	local _isGnu=false
	date --help 2>/dev/null | grep -q "GNU" && _isGnu=true
	if [[ $_isGnu == true ]]; then
		date +%s -r "$1"
	else
		{
			eval "$(stat -s "$1")"
			echo "$st_mtime"
		}
	fi
}
cache.get_dir() {
	echo "${TMPDIR-"/tmp"}/$(cache.get_id)"
}
cache.exist() {
	local _File
	_File="$(cache.create_dir)/$1"
	[[ -e $_File ]] || return 1
	(("$(cache.get_time_diff_from_last_update "$_File")" > "${KEEPCACHESEC-"86400"}")) && return 2
	return 0
}
cache.get_id() {
	if [[ -z ${FSBLIB_CACHEID-""} ]]; then
		cache.create_dir >/dev/null
	fi
	echo "$FSBLIB_CACHEID"
}
cache.get() {
	cat "$(cache.get_dir)/$1" 2>/dev/null || return 1
}
cache.get_time_diff_from_last_update() {
	local _Now _Last
	_Now="$(date "+%s")"
	_Last="$(cache.get_file_last_update "$1")"
	echo "$((_Now - _Last))"
	return 0
}
cache.create_dir() {
	FSBLIB_CACHEID="${FSBLIB_CACHEID-"$(RandomString "10")"}"
	export FSBLIB_CACHEID="$FSBLIB_CACHEID"
	local TMPDIR="${TMPDIR-"/tmp"}"
	local _Dir="$TMPDIR/${FSBLIB_CACHEID}"
	mkdir -p "$_Dir"
	echo "$_Dir"
	return 0
}
cache.create() {
	cache.create_dir >/dev/null
	cat >"$(cache.get_dir)/${1}"
	cat "$(cache.get_dir)/$1"
}
