#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

declare -r FSBLIB_LIBLIST=("AwkForCalc")
declare -r FSBLIB_FUNCLIST=("awk.log" "awk.pi" "awk.print" "awk.rad" "awk.float" "awk.cos" "awk.sin" "awk.tan")
declare -r FSBLIB_VERSION='v0.2.5.1.r355.g77426b4-snake'
declare -r FSBLIB_REQUIRE='Any'

awk.pi() {
	awk.float "atan2(0, -0)"
}
awk.print() {
	awk "BEGIN {print $*}"
}
awk.tan() {
	awk.float "sin($1)/tan($1)"
}
awk.log() {
	awk.float "log(${2}) / log($1)"
}
awk.rad() {
	awk.float "$1 * $(awk.pi) / 180 "
}
awk.sin() {
	awk.float "sin($*)"
}
awk.cos() {
	awk.float "cos($*)"
}
awk.float() {
	awk "BEGIN {printf (\"%4.${AWKSCALE-"5"}f\n\", $*)}"
}
