#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

declare -r FSBLIB_LIBLIST=("BetterShell")
declare -r FSBLIB_FUNCLIST=("strToCharList" "addNewToArray" "arrayAppend" "arrayIncludes" "getArrayIndex" "printEvalArray" "arrayIndex" "printArray" "revArray" "getBaseName" "getFileExt" "removeFileExt" "fileType" "checkFuncDefined" "forEach" "getLine" "isAvailable" "loop" "toLowerStdin" "cutLastString" "isUUID" "randomString" "toLower" "breakChar" "removeBlank" "textBox" "getLastSplitString" "printEval" "sum" "calcInt" "ntest" "bool" "getFuncList" "unsetAllFunc" "match" "removeMatchLine")
declare -r FSBLIB_VERSION='v0.2.5.1.r378.g67898ba-lower'
declare -r FSBLIB_REQUIRE='ModernBash'

strToCharList() {
	Array.FromStr "$1"
}
arrayAppend() {
	Array.Append "$1"
}
arrayIncludes() {
	Array.Includes "$@"
}
getarrayIndex() {
	Array.IndexOf "$1"
}
printEvalArray() {
	Array.Eval "$1"
}
addNewToArray() {
	Array.Push "$@"
}
printArray() {
	Array.Print "$@"
}
arrayIndex() {
	Array.Length "$1"
}
revArray() {
	Array.Rev "$1"
}
getBaseName() {
	forEach basename "{}"
}
fileType() {
	file --mime-type -b "$1"
}
getFileExt() {
	getBaseName | rev | cut -d "." -f 1 | rev
}
removeFileExt() {
	local Ext
	forEach eval 'Ext=$(getFileExt <<< {}); sed "s|.$Ext$||g" <<< {}; unset Ext'
}
isAvailable() {
	type "$1" 2>/dev/null 1>&2
}
checkFuncDefined() {
	typeset -f "${1}" >/dev/null || return 1
}
getLine() {
	head -n "$1" | tail -n 1
}
forEach() {
	local _Item
	while read -r _Item; do
		"${@//"{}"/"${_Item}"}" || return "${?}"
	done
}
loop() {
	local _T="$1"
	shift 1 || return 1
	((_T == 0)) && return 0
	forEach "$@" < <(yes "" | head -n "$_T")
}
cutLastString() {
	echo "${1%%"${2}"}"
	return 0
}
toLowerStdin() {
	local _Str
	forEach eval '_Str="{}"; echo "${_Str,,}"'
	unset _Str
}
breakChar() {
	grep -o "."
}
isUUID() {
	local _UUID="${1-""}"
	[[ ${_UUID//-/} =~ ^[[:xdigit:]]{32}$ ]] && return 0
	return 1
}
toLower() {
	local _Str="${1,,}"
	[[ -z ${_Str-""} ]] || echo "${_Str}"
}
randomString() {
	base64 <"/dev/random" | fold -w "$1" | head -n 1
	return 0
}
getLastSplitString() {
	rev <<<"$2" | cut -d "$1" -f 1 | rev
}
textBox() {
	local _Content=() _Length _Vertical="|" _Line="=" _Header="${1-""}"
	readarray -t _Content
	_Length="$(printArray "${_Content[@]}" "$_Header" | awk '{ if ( length > x && length > 0 ) { x = length } }END{ print x }')"
	if [[ -z ${_Header:-""} ]]; then
		echo "${_Vertical}$(loop "$((_Length + 1))" echo -n "${_Line}")${_Vertical}"
	else
		((_Length % 2 == 0)) || ((_Length++))
		((${#_Header} % 2 == 0)) && ((_Length++))
		echo "${_Vertical}$(loop "$(((_Length - ${#_Header}) / 2))" echo -n "${_Line}")${_Header+" ${_Header} "}$(loop "$(((_Length - ${#_Header}) / 2))" echo -n "${_Line}")${_Vertical}"
	fi
	for _Str in "${_Content[@]}"; do
		echo "${_Vertical}${_Str}$(loop "$((_Length + 1 - "${#_Str}"))" echo -n " ")${_Vertical}"
	done
	echo "${_Vertical}$(loop "$((_Length + 1))" echo -n "${_Line}")${_Vertical}"
}
printEval() {
	eval echo "\${$1}"
}
removeBlank() {
	sed "s|^ *||g; s| *$||g; s|^	*||g; s|	*$||g; /^$/d"
}
ntest() {
	(("$@")) || return 1
}
sum() {
	local _Arg=()
	forEach eval '_Arg+=("{}" "+")' < <(printArray "$@")
	readarray -t _Arg < <(printArray "${_Arg[@]}" | sed "${#_Arg[@]}d")
	calcInt "${_Arg[@]}"
}
calcInt() {
	echo "$(("$@"))"
}
bool() {
	case "$(removeBlank <<<"$(toLower "$1")")" in
	"true")
		return 0
		;;
	"false")
		return 1
		;;
	esac
	case "$(toLower "$(printEval "${1}")")" in
	"true")
		return 0
		;;
	"" | "false")
		return 1
		;;
	*)
		return 2
		;;
	esac
}
getFuncList() {
	declare -F | cut -d " " -f 3
}
unsetAllFunc() {
	local Func
	while read -r Func; do
		unset "$Func"
	done < <(getFuncList)
}
removematchLine() {
	local i unseted=false
	while read -r i; do
		if [[ $i != "${1}" ]] || [[ ${unseted} == true ]]; then
			echo "$i"
		else
			unseted=true
		fi
	done
	unset unseted i
}
match() {
	local stdin str
	read -r stdin
	for str in "$@"; do
		if [[ $str == "$stdin" ]]; then
			return 0
		fi
	done
	return 1
}
