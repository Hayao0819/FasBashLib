#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Esc")
FSBLIB_FUNCLIST+=("Esc.clearLeft" "Esc.clearLine" "Esc.clearRight" "Esc.clearScreen" "Esc.return" "Esc.getTermX" "Esc.getTermY" "Esc.getX" "Esc.getY" "Esc.moveCursor" "Esc.moveCursorDown" "Esc.moveCursorLeft" "Esc.moveCursorRight" "Esc.moveCursorUp" "Esc.clearLineAndReturn" "Esc.clearUpperLines" "Esc.blackBackground" "Esc.blackText" "Esc.blink" "Esc.blueBackground" "Esc.blueText" "Esc.bold" "Esc.conceal" "Esc.crossedOut" "Esc.cyanBackground" "Esc.cyanText" "Esc.greenBackground" "Esc.greenText" "Esc.italic" "Esc.lowIntensity" "Esc.magentaBackground" "Esc.magentaText" "Esc.rapidBlink" "Esc.redBackground" "Esc.redText" "Esc.resetStyle" "Esc.reverse" "Esc.underline" "Esc.whiteBackground" "Esc.whiteText" "Esc.yellowBackground" "Esc.yellowText")
FSBLIB_VERSION='v0.2.7.r413.gcb751ea-lower'
FSBLIB_REQUIRE='ModernBash'

Esc.clearLeft() {
	printf "\033[1K" >/dev/tty
}
Esc.clearLine() {
	printf "\033[2K" >/dev/tty
}
Esc.clearRight() {
	printf "\033[0K" >/dev/tty
}
Esc.clearScreen() {
	printf "\033[2J" >/dev/tty
}
Esc.return() {
	printf "\r" >/dev/tty
}
Esc.getTermX() {
	[[ -n ${COLUMNS-""} ]] && echo "$COLUMNS" && return 0
	tput cols
}
Esc.getTermY() {
	[[ -n ${LINES-""} ]] && echo "$LINES" && return 0
	tput lines
}
Esc.getX() {
	local _POS
	printf "\033[6n" >>/dev/tty
	read -r -s -d "R" _POS
	echo $(("$(printf "%s\n" "${_POS:2}" | cut -d";" -f2)" - 1))
}
Esc.getY() {
	local _POS
	printf "\033[6n" >>/dev/tty
	read -r -s -d "R" _POS
	echo $(("$(printf "%s\n" "${_POS:2}" | cut -d";" -f1)" - 1))
}
Esc.moveCursor() {
	printf "\033[%d;%dH" "$1" "$2" >/dev/tty
}
Esc.moveCursorDown() {
	printf "\033[%dB" "$1" >/dev/tty
}
Esc.moveCursorLeft() {
	printf "\033[%dD" "$1" >/dev/tty
}
Esc.moveCursorRight() {
	printf "\033[%dC" "$1" >/dev/tty
}
Esc.moveCursorUp() {
	printf "\033[%dA" "$1" >/dev/tty
}
Esc.clearLineAndReturn() {
	Esc.clearLine
	Esc.return
}
Esc.clearUpperLines() {
	for i in $(seq 1 "$1"); do
		Esc.moveCursorUp 1
		Esc.clearLine
	done
}
Esc.blackBackground() {
	printf "\033[40m" >/dev/tty
}
Esc.blackText() {
	printf "\033[30m" >/dev/tty
}
Esc.blink() {
	printf "\033[5m" >/dev/tty
}
Esc.blueBackground() {
	printf "\033[44m" >/dev/tty
}
Esc.blueText() {
	printf "\033[34m" >/dev/tty
}
Esc.bold() {
	printf "\033[1m" >/dev/tty
}
Esc.conceal() {
	printf "\033[8m" >/dev/tty
}
Esc.crossedOut() {
	printf "\033[9m" >/dev/tty
}
Esc.cyanBackground() {
	printf "\033[46m" >/dev/tty
}
Esc.cyanText() {
	printf "\033[36m" >/dev/tty
}
Esc.greenBackground() {
	printf "\033[42m" >/dev/tty
}
Esc.greenText() {
	printf "\033[32m" >/dev/tty
}
Esc.italic() {
	printf "\033[3m" >/dev/tty
}
Esc.lowIntensity() {
	printf "\033[2m" >/dev/tty
}
Esc.magentaBackground() {
	printf "\033[45m" >/dev/tty
}
Esc.magentaText() {
	printf "\033[35m" >/dev/tty
}
Esc.rapidBlink() {
	printf "\033[6m" >/dev/tty
}
Esc.redBackground() {
	printf "\033[41m" >/dev/tty
}
Esc.redText() {
	printf "\033[31m" >/dev/tty
}
Esc.resetStyle() {
	printf "\033[0m" >/dev/tty
}
Esc.reverse() {
	printf "\033[7m" >/dev/tty
}
Esc.underline() {
	printf "\033[4m" >/dev/tty
}
Esc.whiteBackground() {
	printf "\033[47m" >/dev/tty
}
Esc.whiteText() {
	printf "\033[37m" >/dev/tty
}
Esc.yellowBackground() {
	printf "\033[43m" >/dev/tty
}
Esc.yellowText() {
	printf "\033[33m" >/dev/tty
}
