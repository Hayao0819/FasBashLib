#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Prompt")
FSBLIB_FUNCLIST+=("captureSpecialKeys" "checkMenu" "choice" "choiceLoop" "selectMenu")
FSBLIB_VERSION='v0.2.6.r453.g306d487-lower'
FSBLIB_REQUIRE='ModernBash'

captureSpecialKeys() {
	local SELECTION rest
	IFS= read -r -n1 -s SELECTION
	if [[ $SELECTION == '' ]]; then
		read -r -n2 -s rest
		SELECTION+="$rest"
	else
		case "$SELECTION" in
		"")
			echo "Enter"
			;;
		'')
			echo "Backspace"
			;;
		' ')
			echo "Space"
			;;
		*)
			read -i "$SELECTION" -e -r rest
			echo "$rest"
			;;
		esac
		return 0
	fi
	case $SELECTION in
	'[A')
		echo "Up"
		;;
	'[B')
		echo "Down"
		;;
	'[C')
		echo "Right"
		;;
	'[D')
		echo "Left"
		;;
	esac
}
checkMenu() {
	local arg OPTARG OPTIND
	local choices=() CurrentSelected=() Key="" Currentchoice=0
	local _question="" _number=false _selected=()
	while getopts "s:p:n" arg; do
		case "${arg}" in
		s)
			_selected+=("${OPTARG}")
			;;
		p)
			_question="${OPTARG}"
			;;
		n)
			_number=true
			;;
		*)
			exit 1
			;;
		esac
	done
	shift "$((OPTIND - 1))" || return 1
	choices=("$@")
	[[ ${#choices[@]} -eq 0 ]] && return 1
	for i in "${!_selected[@]}"; do
		if Array.Include choices "${choices[$i]}"; then
			CurrentSelected+=("$i")
		fi
	done
	if [[ -n $_question ]]; then
		echo "$_question" 1>&2
	fi
	while [[ $Key != "Enter" ]]; do
		for i in "${!choices[@]}"; do
			[[ $i == "$Currentchoice" ]] && {
				Esc.Bold && Esc.Underline
			}
			if [[ ${CurrentSelected[*]} =~ $i ]]; then
				echo " [X] $i: ${choices[$i]}"
			else
				echo " [ ] $i: ${choices[$i]}"
			fi
			Esc.ResetStyle
		done
		Key="$(captureSpecialKeys)"
		case "$Key" in
		Up)
			(("$Currentchoice" != 0)) && Currentchoice=$((Currentchoice - 1))
			;;
		Down)
			(("$Currentchoice" != "${#choices[@]}" - 1)) && Currentchoice=$((Currentchoice + 1))
			;;
		Space)
			if Array.Include CurrentSelected "$Currentchoice"; then
				Array.Remove CurrentSelected "$Currentchoice"
			else
				CurrentSelected+=("$Currentchoice")
			fi
			;;
		esac
		Esc.ClearUpperLines "${#choices[@]}"
	done
	if [[ -n $_question ]]; then
		Esc.ClearUpperLines 1
	fi
	if [[ $_number == true ]]; then
		Array.Eval CurrentSelected
	else
		Array.ForEach CurrentSelected eval 'echo ${choices[{}]}'
	fi
	return 0
}
choice() {
	local arg OPTARG OPTIND
	local _count _choice
	local _default="" _question="" _returnstr="" _mark=" "
	local _count=0 _digit=0 _returnint=
	local _number=false
	local _choice_list=()
	while getopts "ad:p:n" arg; do
		case "${arg}" in
		d)
			_default="${OPTARG}"
			;;
		p)
			_question="${OPTARG}"
			;;
		n)
			_number=true
			;;
		*)
			exit 1
			;;
		esac
	done
	shift "$((OPTIND - 1))" || return 1
	_choice_list=("${@}") _digit="${##}"
	((${#_choice_list[@]} <= 0)) && echo "An exception error has occurred." 1>&2 && exit 1
	((${#_choice_list[@]} == 1)) && _returnint="${_returnint:="1"}" _returnstr="${_returnstr:="${_choice_list[*]}"}"
	[[ -n ${_question-""} ]] && echo "   ${_question}" 1>&2
	for ((_count = 1; _count <= ${#_choice_list[@]}; _count++)); do
		_choice="${_choice_list[$((_count - 1))]}" _mark=" "
		{
			[[ ! ${_default} == "" ]] && [[ ${_choice} == "${_default}" ]]
		} && _mark="*"
		printf " ${_mark} %${_digit}d: ${_choice}\n" "${_count}" 1>&2
	done
	echo -n "   (1 ~ ${#_choice_list[@]}) > " 1>&2 && read -r _input
	{
		[[ -z ${_input-""} ]] && [[ -n ${_default-""} ]]
	} && _returnint="${_returnint:="0"}" _returnstr="${_returnstr:="${_default}"}"
	{
		printf "%s" "${_input}" | grep -qE "^[0-9]+$" && ((1 <= _input)) && ((_input <= ${#_choice_list[@]}))
	} && _returnint="${_returnint:="${_input}"}" _returnstr="${_returnstr:="${_choice_list[$((_input - 1))]}"}"
	for ((i = 0; i <= ${#_choice_list[@]} - 1; i++)); do
		[[ ${_choice_list["${i}"],,} == "${_input,,}" ]] && _returnint="${_returnint:="$((i + 1))"}" _returnstr="${_returnstr:="${_choice_list["${i}"]}"}"
	done
	{
		[[ ${_number} == true ]] && [[ -n ${_returnint:-""} ]]
	} && {
		echo "${_returnint}" && return 0
	}
	{
		[[ ${_number} == false ]] && [[ -n ${_returnstr:-""} ]]
	} && {
		echo "${_returnstr}" && return 0
	}
	return 1
}
choiceLoop() {
	while true; do
		if choice "$@"; then
			break
		fi
	done
}
selectMenu() {
	local arg OPTARG OPTIND
	local choices=() Currentchoice=0 Key=""
	local _question="" _default="" _number=false
	while getopts "ad:p:n" arg; do
		case "${arg}" in
		d)
			_default="${OPTARG}"
			;;
		p)
			_question="${OPTARG}"
			;;
		n)
			_number=true
			;;
		*)
			exit 1
			;;
		esac
	done
	shift "$((OPTIND - 1))" || return 1
	choices=("$@")
	[[ ${#choices[@]} -eq 0 ]] && return 1
	[[ ${#choices[@]} -eq 1 ]] && {
		echo "${choices[0]}" && return 0
	}
	if [[ -n $_default ]] && Array.Include choices "$_default"; then
		Currentchoice="$(Array.Eval choices | Array.IndexOf "$_default")"
	fi
	if [[ -n $_question ]]; then
		echo "$_question" 1>&2
	fi
	while [[ $Key != "Enter" ]]; do
		for i in "${!choices[@]}"; do
			if [[ $i == "$Currentchoice" ]]; then
				Esc.Bold && Esc.Underline
				echo " > $i: ${choices[$i]}"
			else
				echo "   $i: ${choices[$i]}"
			fi
			Esc.ResetStyle
		done
		Key="$(captureSpecialKeys)"
		case "$Key" in
		Up)
			(("$Currentchoice" != 0)) && Currentchoice=$((Currentchoice - 1))
			;;
		Down)
			(("$Currentchoice" != "${#choices[@]}" - 1)) && Currentchoice=$((Currentchoice + 1))
			;;
		esac
		Esc.ClearUpperLines "${#choices[@]}"
	done
	if [[ -n $_question ]]; then
		Esc.ClearUpperLines 1
	fi
	if [[ $_number == true ]]; then
		echo "$Currentchoice"
	else
		echo "${choices[$Currentchoice]}"
	fi
	return 0
}
