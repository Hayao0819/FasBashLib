#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("Misskey")
FSBLIB_FUNCLIST+=("Misskey.notes.Renotes" "Misskey.notes.Search" "Misskey.notes.Create" "Misskey.users.GetFrequentlyRepliedUsers" "Misskey.users.Pages" "Misskey.users.SearchByUsernameAndHost" "Misskey.users.Show" "Misskey.users.Stats" "Misskey.users.Notes" "Misskey.admin.ServerInfo" "Misskey.setup" "Misskey.serverInfo" "Misskey.meta" "Misskey.i" "Misskey.bindingBase" "Misskey.makeJson" "Misskey.sendReq" "Misskey.isAdmin" "Misskey.myName" "Misskey.myUserName" "Misskey.myId")
FSBLIB_VERSION='v0.2.6.r387.gb305fe8-lower'
FSBLIB_REQUIRE='ModernBash'

Misskey.notes.Renotes() {
	Misskey.bindingBase "notes/renotes" noteId limit sinceId untilId -- "$@"
}
Misskey.notes.Search() {
	Misskey.bindingBase "notes/search" query limit -- "$@"
}
Misskey.notes.Create() {
	Misskey.bindingBase "notes/create" text -- "$@"
}
Misskey.users.Notes() {
	Misskey.bindingBase "users/notes" userId -- "${1:-"$(Misskey.myId)"}" "${@:2}"
}
Misskey.users.Show() {
	Misskey.bindingBase "users/show" userId -- "${1:-"$(Misskey.myId)"}" "${@:2}"
}
Misskey.users.GetFrequentlyRepliedUsers() {
	Misskey.bindingBase "users/get-frequently-replied-users" userId -- "${1:-"$(Misskey.myId)"}" "${@:2}"
}
Misskey.users.Pages() {
	Misskey.bindingBase "users/pages" userId -- "${1:-"$(Misskey.myId)"}" "${@:2}"
}
Misskey.users.SearchByUsernameAndHost() {
	Misskey.bindingBase "users/search-by-username-and-host" username -- "${1:-"$(Misskey.myUserName)"}" "${@:2}"
}
Misskey.users.Stats() {
	Misskey.bindingBase "users/stats" userId -- "${1:-"$(Misskey.myId)"}" "${@:2}"
}
Misskey.admin.ServerInfo() {
	Misskey.bindingBase "/admin/server-info" -- "$@"
}
Misskey.setup() {
	export MISSKEY_DOMAIN="${1-"${MISSKEY_DOMAIN-""}"}"
	export MISSKEY_TOKEN="${2-"${MISSKEY_TOKEN-""}"}"
	export MISSKEY_ENTRY="https://${MISSKEY_DOMAIN}/api"
}
Misskey.serverInfo() {
	Misskey.bindingBase "/server-info" -- "$@"
}
Misskey.meta() {
	Misskey.bindingBase "/meta" -- "$@"
}
Misskey.i() {
	Misskey.bindingBase "/i" -- "$@"
}
Misskey.makeJson() {
	local i _Key _Value
	for i in "i=$MISSKEY_TOKEN" "$@"; do
		_Key=$(cut -d "=" -f 1 <<<"$i")
		_Value=$(cut -d "=" -f 2- <<<"$i")
		if [[ $_Value =~ ^[0-9]+$ ]] || [[ $_Value == true ]] || [[ $_Value == false ]] || [[ $_Value == "{"*"}" ]] || [[ $_Value == "["*"]" ]]; then
			echo -n "{\"$_Key\": $_Value}"
		else
			echo -n "{\"$_Key\": \"$_Value\"}"
		fi
	done | sed "s|}{|,|g" | jq -c -M
}
Misskey.bindingBase() {
	local _API="$1"
	shift 1
	local i _APIArgs=("") _Args
	for i in "$@"; do
		shift 1 2>/dev/null || true
		if [[ $i == "--" ]]; then
			break
		else
			_APIArgs+=("$i")
		fi
	done
	local _Cnt _Shifted=false
	for ((_Cnt = 1; _Cnt <= "${#_APIArgs[@]} - 1"; _Cnt++)); do
		_Args+=("${_APIArgs[$_Cnt]}=$(eval echo "\${${_Cnt}:-""}")")
		if [[ -z "$(eval echo "\${$((_Cnt + 1)):-""}")" ]]; then
			shift "$_Cnt"
			_Shifted=true
			break
		fi
	done
	if ! Bool _Shifted; then
		_Shifted=true
		shift "$((${#_APIArgs[@]} - 1))"
	fi
	if [[ -z ${MISSKEY_ENTRY-""} ]]; then
		Misskey.setup "${MISSKEY_DOMAIN}" "$MISSKEY_TOKEN"
	fi
	Misskey.sendReq "${MISSKEY_ENTRY%/}/${_API#/}" "${_Args[@]}" "$@"
}
Misskey.sendReq() {
	local _Url="$1" _CurlArgs=()
	shift 1
	_CurlArgs+=(-s -L)
	_CurlArgs+=(-X POST)
	_CurlArgs+=(-H "Content-Type: application/json")
	_CurlArgs+=(-d "$(Misskey.makeJson "$@")")
	_CurlArgs+=("$_Url")
	Msg.Debug "Run: ${_CurlArgs[*]//"${MISSKEY_TOKEN}"/"TOKEN"}"
	curl "${_CurlArgs[@]}"
}
Misskey.isAdmin() {
	Bool "$(Misskey.i | jq -r ".isAdmin")"
}
Misskey.myUserName() {
	Misskey.i | jq -r ".username"
}
Misskey.myName() {
	Misskey.i | jq -r ".name"
}
Misskey.myId() {
	Misskey.i | jq -r ".id"
}
