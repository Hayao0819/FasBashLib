#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
#
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_LIBLIST+=("URL")
FSBLIB_FUNCLIST+=("URL.fragment" "URL.host" "URL.noScheme" "URL.path" "URL.pathAndQueryAndFragment" "URL.query" "URL.authority" "URL.scheme" "URL.user" "URL.port" "URL.hasFragment" "URL.hasUser" "URL.hasQuery" "URL.hasAuthority" "URL.hasPort" "URL.parse" "URL.getQuery" "URL.parseQuery")
FSBLIB_VERSION='v0.2.5.1.r414.ge490053-lower'
FSBLIB_REQUIRE='ModernBash'

URL.fragment() {
	local i
	i="$(URL.pathAndQueryAndFragment)"
	[[ $i == *"#"* ]] || return 0
	cut -d "#" -f 2- <<<"$i"
}
URL.noScheme() {
	cut -d ":" -f 2-
}
URL.path() {
	URL.pathAndQueryAndFragment | cut -d "#" -f 1 | cut -d "?" -f 1
}
URL.authority() {
	local i _NoScheme
	while read -r i; do
		_NoScheme=$(URL.noScheme <<<"$i")
		[[ $_NoScheme == "//"* ]] || return 1
		cut -d "/" -f 1 < <(sed "s|^//||g" <<<"$_NoScheme")
	done
}
URL.pathAndQueryAndFragment() {
	local i
	while read -r i; do
		sed "s|^//$(URL.authority <<<"$i")||g" <<<"$(URL.noScheme <<<"$i")"
	done
}
URL.host() {
	URL.authority | cut -d "@" -f 2- | cut -d ":" -f 1
}
URL.user() {
	local i
	while read -r i; do
		[[ $i == *"@"* ]] || {
			echo ""
			continue
		}
		cut -d "@" -f 1 <<<"$i"
	done < <(URL.authority)
}
URL.scheme() {
	cut -d ":" -f 1
}
URL.query() {
	local i
	while read -r i; do
		URL.pathAndQueryAndFragment <<<"$i" | sed "s|#$(URL.fragment <<<"$i")||g" | cut -d "?" -f 2-
	done
}
URL.port() {
	local i
	while read -r i; do
		[[ $i == *":"* ]] || {
			continue
		}
		cut -d ":" -f 2 <<<"$i"
	done < <(URL.authority)
}
URL.hasUser() {
	local i="${1-""}"
	[[ -n $i ]] || read -r i
	[[ "$(URL.authority <<<"$i")" == *"@"* ]]
}
URL.hasQuery() {
	local i="${1-""}"
	[[ -n $i ]] || read -r i
	[[ "$(URL.pathAndQueryAndFragment <<<"$i")" == *"?"* ]]
}
URL.hasAuthority() {
	local i="${1-""}"
	[[ -n $i ]] || read -r i
	[[ "$(URL.noScheme <<<"$i")" == "//"* ]]
}
URL.hasFragment() {
	local i="${1-""}"
	[[ -n $i ]] || read -r i
	[[ "$(URL.pathAndQueryAndFragment <<<"$i")" == *"#"* ]]
}
URL.hasPort() {
	local i="${1-""}"
	[[ -n $i ]] || read -r i
	[[ "$(URL.authority <<<"$i")" == *":"* ]]
}
URL.parse() {
	local i="${1-""}"
	if [[ -z ${i} ]]; then
		read -r i
	fi
	URL.scheme <<<"$i"
	echo ":"
	if URL.hasAuthority "$i"; then
		if URL.hasUser "$i"; then
			URL.user <<<"$i"
			echo "@"
		fi
		URL.host <<<"$i"
		if URL.hasPort "$i"; then
			echo ":"
			URL.port <<<"$i"
		fi
	fi
	URL.path <<<"$i"
	if URL.hasFragment "$i"; then
		echo "#"
		URL.fragment <<<"$i"
	fi
	if URL.hasQuery "$i"; then
		echo "?"
		URL.query <<<"$i"
	fi
}
URL.getQuery() {
	grep "^ *$1=" | cut -d "=" -f 2-
}
URL.parseQuery() {
	local i="${1-""}"
	if [[ -z ${i} ]]; then
		read -r i
	fi
	if grep -q "[a-zA-Z]://" <<<"$i"; then
		i="$(URL.query <<<"$i")"
	fi
	i="$(sed "s|^\?||g" <<<"$i")"
	tr "&" "\n" <<<"$i" | cut -d "#" -f 1
}
