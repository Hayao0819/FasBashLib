#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_VERSION="0.2.4.r234.g5c62fb4-upper"
FSBLIB_REQUIRE="ModernBash"

URL.Authority () 
{ 
    local i _NoScheme;
    while read -r i; do
        _NoScheme=$(URL.NoScheme <<< "$i");
        [[ "$_NoScheme" == "//"* ]] || return 1;
        cut -d "/" -f 1 < <(sed "s|^//||g" <<< "$_NoScheme");
    done
}
URL.Fragment () 
{ 
    local i;
    i="$(URL.PathAndQueryAndFragment)";
    [[ "$i" == *"#"* ]] || return 0;
    cut -d "#" -f 2- <<< "$i"
}
URL.Host () 
{ 
    URL.Authority | cut -d "@" -f 2- | cut -d ":" -f 1
}
URL.NoScheme () 
{ 
    cut -d ":" -f 2-
}
URL.Path () 
{ 
    URL.PathAndQueryAndFragment | cut -d "#" -f 1 | cut -d "?" -f 1
}
URL.PathAndQueryAndFragment () 
{ 
    local i;
    while read -r i; do
        sed "s|^//$(URL.Authority <<< "$i")||g" <<< "$(URL.NoScheme <<< "$i")";
    done
}
URL.Port () 
{ 
    local i;
    while read -r i; do
        [[ "$i" == *":"* ]] || { 
            continue
        };
        cut -d ":" -f 2 <<< "$i";
    done < <(URL.Authority)
}
URL.Query () 
{ 
    local i;
    while read -r i; do
        URL.PathAndQueryAndFragment <<< "$i" | sed "s|#$(URL.Fragment <<< "$i")||g" | cut -d "?" -f 2-;
    done
}
URL.Scheme () 
{ 
    cut -d ":" -f 1
}
URL.User () 
{ 
    local i;
    while read -r i; do
        [[ "$i" == *"@"* ]] || { 
            echo "";
            continue
        };
        cut -d "@" -f 1 <<< "$i";
    done < <(URL.Authority)
}
URL.HasAuthority () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(URL.NoScheme <<< "$i")" = "//"* ]]
}
URL.HasFragment () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(URL.PathAndQueryAndFragment <<< "$i")" = *"#"* ]]
}
URL.HasPort () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(URL.Authority <<< "$i")" = *":"* ]]
}
URL.HasQuery () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(URL.PathAndQueryAndFragment <<< "$i")" = *"?"* ]]
}
URL.HasUser () 
{ 
    local i="${1-""}";
    [[ -n "$i" ]] || read -r i;
    [[ "$(URL.Authority <<< "$i")" = *"@"* ]]
}
URL.Parse () 
{ 
    local i="${1-""}";
    if [[ -z "${i}" ]]; then
        read -r i;
    fi;
    URL.Scheme <<< "$i";
    echo ":";
    if URL.HasAuthority "$i"; then
        if URL.HasUser "$i"; then
            URL.User <<< "$i";
            echo "@";
        fi;
        URL.Host <<< "$i";
        if URL.HasPort "$i"; then
            echo ":";
            URL.Port <<< "$i";
        fi;
    fi;
    URL.Path <<< "$i";
    if URL.HasFragment "$i"; then
        echo "#";
        URL.Fragment <<< "$i";
    fi;
    if URL.HasQuery "$i"; then
        echo "?";
        URL.Query <<< "$i";
    fi
}
URL.GetQuery () 
{ 
    grep "^ *$1=" | cut -d "=" -f 2-
}
URL.ParseQuery () 
{ 
    local i="${1-""}";
    if [[ -z "${i}" ]]; then
        read -r i;
    fi;
    if grep -q "[a-zA-Z]://" <<< "$i"; then
        i="$(URL.Query <<< "$i")";
    fi;
    i="$(sed "s|^\?||g" <<< "$i")";
    tr "&" "\n" <<< "$i" | cut -d "#" -f 1
}
