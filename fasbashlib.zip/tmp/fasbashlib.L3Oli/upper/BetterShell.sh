#!/usr/bin/env bash
#
# <FasBashLib>
# A collection of small but awasome functions for Bash
#
# <Document>
# You can read the document here.
# https://github.com/Hayao0819/FasBashLib/tree/build-0.2.x/docs
#
# <E-Mail>
# Yamada Hayao <hayao@fascode.net>
# Fascode Network <contact@fascode.net>
#
# <Twitter>
# Yamada Hayao <@Hayao0819>
# 
# <LICENSE>
# "THE MIT SUSHI-WARE LICENSE"
# based "SUSHI-WARE LICENSE" (https://github.com/MakeNowJust/sushi-ware)
# Copyright 2022 Yamada Hayao
#
# - You agree that "the author (copyright holder) is not responsible for the software".
# - You place a copyright notice or this permission notice on all copies of the Software or any other material part of the Software.
#   If the above two conditions are met, the following rights are granted.
# - The right to use, copy, modify and redistribute without charge and without restriction.
# - The right to buy the author (copyright holder) of the software a bowl of sushi🍣.
#
# shellcheck disable=all

FSBLIB_VERSION="v0.2.3.r300.gac11343-upper"
FSBLIB_REQUIRE="ModernBash"

AddNewToArray () 
{ 
    Array.Push "$@"
}
ArrayAppend () 
{ 
    Array.Append "$1"
}
ArrayIncludes () 
{ 
    Array.Includes "$@"
}
ArrayIndex () 
{ 
    Array.Length "$1"
}
GetArrayIndex () 
{ 
    Array.IndexOf "$1"
}
PrintArray () 
{ 
    Array.Print "$@"
}
PrintEvalArray () 
{ 
    Array.Eval "$1"
}
RevArray () 
{ 
    Array.Rev "$1"
}
StrToCharList () 
{ 
    Array.FromStr "$1"
}
FileType () 
{ 
    file --mime-type -b "$1"
}
GetBaseName () 
{ 
    ForEach basename "{}"
}
GetFileExt () 
{ 
    GetBaseName | rev | cut -d "." -f 1 | rev
}
RemoveFileExt () 
{ 
    local Ext;
    ForEach eval 'Ext=$(GetFileExt <<< {}); sed "s|.$Ext$||g" <<< {}; unset Ext'
}
CheckFuncDefined () 
{ 
    typeset -f "${1}" > /dev/null || return 1
}
ForEach () 
{ 
    local _Item;
    while read -r _Item; do
        "${@//"{}"/"${_Item}"}" || return "${?}";
    done
}
GetLine () 
{ 
    head -n "$1" | tail -n 1
}
IsAvailable () 
{ 
    type "$1" 2> /dev/null 1>&2
}
Loop () 
{ 
    local _T="$1";
    shift 1 || return 1;
    ForEach "$@" < <(yes "" | head -n "$_T")
}
BreakChar () 
{ 
    grep -o "."
}
CutLastString () 
{ 
    echo "${1%%"${2}"}";
    return 0
}
GetLastSplitString () 
{ 
    rev <<< "$2" | cut -d "$1" -f 1 | rev
}
IsUUID () 
{ 
    local _UUID="${1-""}";
    [[ "${_UUID//-/}" =~ ^[[:xdigit:]]{32}$ ]] && return 0;
    return 1
}
PrintEval () 
{ 
    eval echo "\${$1}"
}
RandomString () 
{ 
    base64 < "/dev/random" | fold -w "$1" | head -n 1;
    return 0
}
RemoveBlank () 
{ 
    sed "s|^ *||g; s| *$||g; s|^	*||g; s|	*$||g; /^$/d"
}
TextBox () 
{ 
    local _Content=() _Length _Vertical="|" _Line="=";
    readarray -t _Content;
    _Length="$(PrintArray "${_Content[@]}" | awk '{ if ( length > x ) { x = length } }END{ print x }')";
    echo "${_Vertical}${_Line}$(yes "${_Line}" | head -n "$_Length" | tr -d "\n")${_Vertical}";
    for _Str in "${_Content[@]}";
    do
        echo "${_Vertical}${_Str}$(yes " " | head -n "$(( _Length + 1 - "${#_Str}"))" | tr -d "\n")${_Vertical}";
    done;
    echo "${_Vertical}${_Line}$(yes "${_Line}" | head -n "$_Length" | tr -d "\n")${_Vertical}"
}
ToLower () 
{ 
    local _Str="${1,,}";
    [[ -z "${_Str-""}" ]] || echo "${_Str}"
}
ToLowerStdin () 
{ 
    local _Str;
    ForEach eval "_Str=\"{}\"; echo \"\${_Str,,}\"";
    unset _Str
}
CalcInt () 
{ 
    echo "$(( "$@" ))"
}
Ntest () 
{ 
    (( "$@" )) || return 1
}
Sum () 
{ 
    local _Arg=();
    ForEach eval '_Arg+=("{}" "+")' < <(PrintArray "$@");
    readarray -t _Arg < <(PrintArray "${_Arg[@]}" | sed "${#_Arg[@]}d");
    CalcInt "${_Arg[@]}"
}
Bool () 
{ 
    case "$(ToLower "$(PrintEval "${1}")")" in 
        "true")
            return 0
        ;;
        "" | "false")
            return 1
        ;;
        *)
            return 2
        ;;
    esac
}
GetFuncList () 
{ 
    declare -F | cut -d " " -f 3
}
UnsetAllFunc () 
{ 
    local Func;
    while read -r Func; do
        unset "$Func";
    done < <(GetFuncList)
}
RemoveMatchLine () 
{ 
    local i unseted=false;
    while read -r i; do
        if [[ "$i" != "${1}" ]] || [[ "${unseted}" = true ]]; then
            echo "$i";
        else
            unseted=true;
        fi;
    done;
    unset unseted i
}
